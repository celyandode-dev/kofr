// ================================================================
// LES IA PRISES EN CHARGE
//
// Kofr écrit dans le champ de saisie et lit la réponse affichée.
// Rien de tout cela n'est propre à ChatGPT : c'est la même mécanique
// partout. Il suffit de déclarer les adresses.
//
// Le mode sans trace, lui, ne se généralise PAS : seul ChatGPT
// expose un paramètre d'adresse qui ouvre une conversation
// temporaire. Chez les autres, c'est un interrupteur dans leur
// propre interface. On ne l'invente pas, on le dit.
// ================================================================

const SITES_IA = [
  {
    cle: "chatgpt",
    nom: "ChatGPT",
    motifs: ["https://chatgpt.com/*", "https://chat.openai.com/*"],
    hotes: ["chatgpt.com", "chat.openai.com"],
    accueil: "https://chatgpt.com/",
    temporaire: "https://chatgpt.com/?temporary-chat=true"
  },
  {
    cle: "claude",
    nom: "Claude",
    motifs: ["https://claude.ai/*"],
    hotes: ["claude.ai"],
    accueil: "https://claude.ai/new",
    temporaire: null
  },
  {
    cle: "gemini",
    nom: "Gemini",
    motifs: ["https://gemini.google.com/*"],
    hotes: ["gemini.google.com"],
    accueil: "https://gemini.google.com/app",
    temporaire: null
  },
  {
    cle: "mistral",
    nom: "Mistral",
    motifs: ["https://chat.mistral.ai/*"],
    hotes: ["chat.mistral.ai"],
    accueil: "https://chat.mistral.ai/chat",
    temporaire: null
  }
];

const TOUS_MOTIFS = SITES_IA.reduce((t, s) => t.concat(s.motifs), []);

function siteParCle(cle) {
  return SITES_IA.find((s) => s.cle === cle) || SITES_IA[0];
}

function siteDeLOnglet(onglet) {
  if (!onglet || !onglet.url) return null;
  let hote;
  try { hote = new URL(onglet.url).hostname; } catch (e) { return null; }
  return SITES_IA.find((s) => s.hotes.indexOf(hote) !== -1) || null;
}
