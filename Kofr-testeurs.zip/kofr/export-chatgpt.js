// ---------------------------------------------------------------
// Kofr — export-chatgpt.js
//
// Lit le fichier conversations.json de l'export ChatGPT et en
// extrait les phrases où l'utilisateur parle de LUI.
//
// Tout se passe dans le navigateur. Le fichier ne quitte jamais
// l'ordinateur — il n'est même pas envoyé au coffre : seules les
// phrases cochées le seront, et chiffrées.
// ---------------------------------------------------------------

// Les tournures par lesquelles quelqu'un parle de soi.
// En français et en anglais : les conversations sont souvent mélangées.
const MARQUEURS = [
  "je suis", "j'ai", "je m'appelle", "j'habite", "je vis", "je travaille",
  "je bosse", "je fais", "je veux", "je dois", "j'aime", "je préfère",
  "je cherche", "je prépare", "je viens de", "mon ", "ma ", "mes ",
  "chez moi", "dans mon", "dans ma",
  "i am ", "i'm ", "i have ", "i live", "i work", "i want", "i like",
  "i prefer", "i study", "my ", "i need", "i'm working"
];

function normaliserTexte(t) {
  return t.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
}

// Une phrase parle-t-elle de la personne ?
function parleDeSoi(phrase) {
  const n = normaliserTexte(phrase);
  return MARQUEURS.some(function (m) {
    return n.includes(normaliserTexte(m));
  });
}

// Récupère tous les messages écrits par l'utilisateur.
function messagesUtilisateur(donnees) {
  const sortie = [];

  donnees.forEach(function (conversation) {
    const mapping = conversation.mapping || {};
    Object.keys(mapping).forEach(function (cle) {
      const noeud = mapping[cle];
      const msg = noeud && noeud.message;
      if (!msg || !msg.author || msg.author.role !== "user") return;

      const contenu = msg.content;
      if (!contenu || !contenu.parts) return;

      contenu.parts.forEach(function (part) {
        if (typeof part === "string" && part.trim()) {
          sortie.push({
            texte: part.trim(),
            date: msg.create_time || conversation.create_time || 0
          });
        }
      });
    });
  });

  return sortie;
}

// Découpe un message en phrases exploitables.
function enPhrases(texte) {
  return texte
    .split(/[.!?\n]+/)
    .map(function (p) { return p.trim(); })
    .filter(function (p) { return p.length >= 20 && p.length <= 300; });
}

// --- LE POINT D'ENTRÉE ------------------------------------------
// Renvoie une liste de phrases candidates, les plus récentes d'abord,
// sans doublons, plafonnée pour rester lisible.
function extraireFaits(donnees, plafond) {
  const messages = messagesUtilisateur(donnees);
  messages.sort(function (a, b) { return b.date - a.date; });

  const vus = new Set();
  const retenues = [];

  for (let i = 0; i < messages.length; i++) {
    const phrases = enPhrases(messages[i].texte);
    for (let j = 0; j < phrases.length; j++) {
      const p = phrases[j];
      if (!parleDeSoi(p)) continue;

      const empreinte = normaliserTexte(p).replace(/[^a-z0-9]/g, "");
      if (vus.has(empreinte)) continue;

      vus.add(empreinte);
      retenues.push(p);
      if (retenues.length >= plafond) return retenues;
    }
  }

  return retenues;
}
