// ---------------------------------------------------------------
// Kofr — fond.js
//
// Le service de fond. Deux rôles :
//   1. poser une pastille sur l'icône quand quelque chose attend
//   2. répondre au bouton flottant installé dans ChatGPT
//
// POURQUOI ICI. Le bouton flottant vit dans la page de ChatGPT.
// La clé du coffre ne doit JAMAIS y descendre. Le bouton envoie
// donc seulement du texte ; le chiffrement a lieu ici, dans
// l'extension, avec la clé de session. La page ne voit rien.
// ---------------------------------------------------------------

importScripts("crypto.js");

const COFFRE = "https://kofr-coffre.celyandode.workers.dev";

// --- LA PASTILLE SUR L'ICÔNE ------------------------------------
chrome.storage.onChanged.addListener(function (changements, zone) {
  if (zone !== "local" || !changements.kofrTache) return;

  const t = changements.kofrTache.newValue;

  if (t && t.etat === "fini") {
    chrome.action.setBadgeText({ text: "1" });
    chrome.action.setBadgeBackgroundColor({ color: "#14453D" });
    chrome.action.setTitle({ title: "Kofr — un résumé vous attend" });
  } else if (t && (t.etat === "a_envoyer" || t.etat === "attente")) {
    chrome.action.setBadgeText({ text: "…" });
    chrome.action.setBadgeBackgroundColor({ color: "#9AA0A8" });
    chrome.action.setTitle({ title: "Kofr — lecture en cours" });
  } else {
    chrome.action.setBadgeText({ text: "" });
    chrome.action.setTitle({ title: "Kofr" });
  }
});

// --- LA SESSION -------------------------------------------------
// Le coffre est-il ouvert ? La clé vit en mémoire de session, elle
// disparaît quand le navigateur se ferme ou qu'on verrouille.
async function session() {
  try {
    const d = await chrome.storage.session.get("kofrSession");
    const s = d.kofrSession;
    if (!s || !s.cle || !s.jeton || !s.compte) return null;
    return s;
  } catch (e) {
    return null;
  }
}

function entetes(s, avecJson) {
  const h = { "X-Kofr-Jeton": s.jeton, "X-Kofr-Compte": s.compte };
  if (avecJson) h["Content-Type"] = "application/json";
  return h;
}

// --- LA LISTE DES PROJETS ---------------------------------------
// Le serveur ne sait pas ce qu'est un projet : le nom est à
// l'intérieur du chiffré. On ouvre donc tout, ici.
async function listerProjets(s) {
  try {
    const r = await fetch(COFFRE + "/notes", { headers: entetes(s, false) });
    const data = await r.json();
    const noms = new Set();

    for (const note of (data.notes || [])) {
      const clair = await dechiffrer(note.texte, s.cle);
      if (clair === null) continue;
      try {
        const o = JSON.parse(clair);
        if (o && typeof o.t === "string" && o.d) noms.add(o.d);
      } catch (e) {}
    }
    return Array.from(noms).sort();
  } catch (e) {
    return [];
  }
}

// --- RANGER UNE NOTE --------------------------------------------
async function rangerNote(s, projet, texte) {
  const paquet = await chiffrer(JSON.stringify({
    d: projet || "",
    t: texte,
    j: new Date().toISOString()
  }), s.cle);

  const r = await fetch(COFFRE + "/note", {
    method: "POST",
    headers: entetes(s, true),
    body: JSON.stringify({ texte: paquet })
  });
  return r.ok;
}

// --- CE QUE LE BOUTON FLOTTANT PEUT DEMANDER --------------------
chrome.runtime.onMessage.addListener(function (message, expediteur, repondre) {
  if (!message || !message.kofr) return;

  // On n'écoute que nos propres pages.
  const origine = expediteur && expediteur.url ? expediteur.url : "";
  if (origine.indexOf("https://chatgpt.com/") !== 0 &&
      origine.indexOf("https://chat.openai.com/") !== 0) {
    repondre({ ouvert: false, ok: false, raison: "origine" });
    return true;
  }

  if (message.kofr === "etat") {
    (async function () {
      const s = await session();
      if (!s) return repondre({ ouvert: false });
      repondre({ ouvert: true, projets: await listerProjets(s) });
    })();
    return true;
  }

  if (message.kofr === "ranger") {
    (async function () {
      const s = await session();
      if (!s) return repondre({ ok: false, raison: "verrouille" });

      const texte = (message.texte || "").trim();
      if (!texte) return repondre({ ok: false, raison: "vide" });

      try {
        repondre({ ok: await rangerNote(s, message.projet || "", texte) });
      } catch (e) {
        repondre({ ok: false, raison: "echec" });
      }
    })();
    return true;
  }
});
