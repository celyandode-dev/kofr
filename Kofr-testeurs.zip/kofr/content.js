// ---------------------------------------------------------------
// Kofr — content.js
//
// Le RÉSIDENT. Contrairement à un script injecté de passage, celui-ci
// est réinstallé par le navigateur à chaque chargement de page.
//
// Il regarde s'il y a un travail en attente, et le reprend. C'est ce
// qui lui permet de survivre au changement d'adresse que l'IA
// déclenche quand on envoie un message.
// ---------------------------------------------------------------

(function () {
  // On peut être installé deux fois : une par le manifeste au
  // chargement de la page, une par le popup.
  //
  // ET SURTOUT : après une mise à jour de l'extension, le résident
  // précédent est mort sans le savoir — mais son drapeau, lui,
  // reste dans la page. Un simple « si déjà là, on s'en va »
  // rendait donc l'onglet sourd jusqu'au prochain rafraîchissement.
  //
  // On numérote plutôt les générations : la plus récente prend la
  // main, les précédentes se taisent d'elles-mêmes.
  const maGeneration = (window.__kofrGeneration || 0) + 1;
  window.__kofrGeneration = maGeneration;
  const perime = function () { return window.__kofrGeneration !== maGeneration; };

  const pause = function (ms) {
    return new Promise(function (r) { setTimeout(r, ms); });
  };

  const lire = function () {
    return new Promise(function (r) {
      chrome.storage.local.get("kofrTache", function (d) { r(d.kofrTache || null); });
    });
  };

  const ecrire = function (v) {
    return new Promise(function (r) {
      chrome.storage.local.set({ kofrTache: v }, r);
    });
  };

  const lireColler = function () {
    return new Promise(function (r) {
      chrome.storage.local.get("kofrColler", function (d) { r(d.kofrColler || null); });
    });
  };

  const oublierColler = function () {
    return new Promise(function (r) { chrome.storage.local.remove("kofrColler", r); });
  };

  const trouverSaisie = function () {
    return (
      document.querySelector("#prompt-textarea") ||
      document.querySelector('div[contenteditable="true"]') ||
      document.querySelector("textarea")
    );
  };

  // Toutes les réponses de l'IA présentes sur la page.
  //
  // Chaque IA a sa propre façon de baliser ses messages, et elles
  // changent leur interface sans prévenir. On essaie donc les pistes
  // propres au site d'abord, puis des repères génériques.
  //
  // NOTE : écrire dans le champ de saisie marche partout sans
  // adaptation (contenteditable ou textarea). C'est seulement la
  // LECTURE de la réponse qui demande de connaître le site.
  const PISTES_REPONSES = {
    "chatgpt.com": [
      '[data-message-author-role="assistant"]'
    ],
    "chat.openai.com": [
      '[data-message-author-role="assistant"]'
    ],
    "claude.ai": [
      '[data-testid="assistant-message"]',
      ".font-claude-message",
      ".font-claude-response",
      "[data-is-streaming]"
    ],
    "gemini.google.com": [
      "message-content",
      ".model-response-text",
      "model-response"
    ],
    "chat.mistral.ai": [
      '[data-message-author-role="assistant"]',
      "[data-message-part-type]"
    ]
  };

  const PISTES_GENERIQUES = [
    '[data-message-author-role="assistant"]',
    '[data-role="assistant"]',
    ".markdown",
    ".prose"
  ];

  const reponsesIA = function () {
    const propres = PISTES_REPONSES[location.hostname] || [];
    const strategies = propres.concat(PISTES_GENERIQUES);
    for (let i = 0; i < strategies.length; i++) {
      let trouve;
      try { trouve = document.querySelectorAll(strategies[i]); }
      catch (e) { continue; }
      if (trouve.length) return Array.from(trouve);
    }
    return [];
  };

  // --- COLLER UN TEXTE ------------------------------------------
  // Kofr écrit dans le champ. La personne relit, puis appuie sur
  // Entrée. C'est elle qui envoie, jamais nous.
  let collageEnCours = false;

  async function coller(texte) {
    if (perime() || collageEnCours) return;
    collageEnCours = true;

    let saisie = trouverSaisie();
    for (let i = 0; i < 40 && !saisie; i++) {
      await pause(250);
      saisie = trouverSaisie();
    }
    if (!saisie) { collageEnCours = false; return; }

    await oublierColler();          // une seule fois, quoi qu'il arrive

    saisie.focus();
    if (saisie.tagName === "TEXTAREA") {
      const setter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype, "value"
      ).set;
      setter.call(saisie, texte + "\n\n");
      saisie.dispatchEvent(new Event("input", { bubbles: true }));
    } else {
      document.execCommand("insertText", false, texte + "\n\n");
    }
    saisie.focus();
    collageEnCours = false;
  }

  // --- ENVOYER LA DEMANDE ---------------------------------------
  async function envoyer(tache) {
    if (perime()) return;
    let saisie = trouverSaisie();
    for (let i = 0; i < 40 && !saisie; i++) {
      await pause(250);
      saisie = trouverSaisie();
    }
    if (!saisie) {
      await ecrire({ etat: "echec", raison: "zone de saisie introuvable" });
      return;
    }

    // On bascule en attente AVANT d'envoyer : si la page navigue
    // juste après, le résident suivant ne renverra pas le message.
    await ecrire({ etat: "attente", debut: Date.now(), extrait: tache.demande.slice(0, 40) });

    saisie.focus();
    if (saisie.tagName === "TEXTAREA") {
      const setter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype, "value"
      ).set;
      setter.call(saisie, tache.demande);
      saisie.dispatchEvent(new Event("input", { bubbles: true }));
    } else {
      document.execCommand("insertText", false, tache.demande);
    }

    await pause(600);

    // On N'ENVOIE PAS à la place de l'utilisateur.
    // Kofr écrit le texte, la personne appuie sur Entrée.
    // Écrire dans un champ est le métier normal d'une extension ;
    // cliquer à la place de quelqu'un sur un service tiers, non.
    saisie.focus();

    await guetter();
  }

  // --- GUETTER LA RÉPONSE ---------------------------------------
  // Reprend aussi après un rechargement de page : on ne sait plus
  // combien il y avait de messages avant, alors on surveille
  // simplement la dernière réponse jusqu'à ce qu'elle se fige.
  async function guetter() {
    let dernierTexte = "";
    let stable = 0;

    for (let i = 0; i < 300; i++) {   // 2 min 30 max
      await pause(500);

      if (perime()) return;                           // remplacé par plus récent
      const tache = await lire();
      if (!tache || tache.etat !== "attente") return;  // annulé ailleurs

      const reponses = reponsesIA();
      if (!reponses.length) continue;

      const texte = (reponses[reponses.length - 1].innerText || "").trim();
      if (!texte) continue;

      if (texte === dernierTexte) {
        stable++;
        // Figé pendant 2 secondes : l'IA a fini d'écrire.
        if (stable >= 4) {
          await ecrire({ etat: "fini", texte: texte });
          return;
        }
      } else {
        stable = 0;
        dernierTexte = texte;
      }
    }

    await ecrire({ etat: "echec", raison: "pas de reponse complete" });
  }

  // --- AU CHARGEMENT DE LA PAGE ---------------------------------
  (async function () {
    await pause(800);              // laisser la page se dessiner

    const aColler = await lireColler();
    if (aColler && aColler.texte) await coller(aColler.texte);

    const tache = await lire();
    if (!tache) return;

    if (tache.etat === "a_envoyer") await envoyer(tache);
    else if (tache.etat === "attente") await guetter();
  })();

  // Et si une demande arrive alors que la page est déjà ouverte.
  chrome.storage.onChanged.addListener(function (changements) {
    if (perime()) return;
    if (changements.kofrColler) {
      const v = changements.kofrColler.newValue;
      if (v && v.texte) coller(v.texte);
    }
    if (changements.kofrTache) {
      const nouveau = changements.kofrTache.newValue;
      if (nouveau && nouveau.etat === "a_envoyer") envoyer(nouveau);
    }
  });

  // ==============================================================
  // LE BOUTON FLOTTANT
  //
  // Le geste qui manquait : sauver sans quitter la conversation.
  // On oublie de ranger parce qu'il faut sortir de la page ; ici,
  // il n'y a plus à sortir.
  //
  // Tout vit dans un « shadow DOM » — une bulle isolée. Le style de
  // Le site ne peut pas l'abîmer, et le nôtre ne touche pas au sien.
  //
  // LA CLÉ NE DESCEND PAS ICI. Ce bouton n'envoie que du texte au
  // service de fond, qui chiffre de son côté. Cette page ne voit
  // jamais de quoi ouvrir le coffre.
  // ==============================================================

  const ID_HOTE = "kofr-bouton-flottant";

  const STYLE = `<style>
    :host{all:initial;}
    *{box-sizing:border-box; font-family:-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;}
    .zone{position:absolute; right:22px; bottom:22px; display:flex;
          flex-direction:column; align-items:flex-end; gap:10px;}
    .pastille{
      width:46px; height:46px; border-radius:50%; border:none; cursor:pointer;
      background:#14453D; color:#F4F1E8; font-size:17px; font-weight:700;
      letter-spacing:.02em; box-shadow:0 3px 14px rgba(0,0,0,.28);
      display:flex; align-items:center; justify-content:center;
    }
    .pastille:hover{background:#0F3730;}
    .pastille.pret{box-shadow:0 0 0 4px rgba(20,69,61,.22), 0 3px 14px rgba(0,0,0,.28);}
    .panneau{
      width:320px; background:#FAF9F6; color:#16181D;
      border:1px solid #E2DED4; border-radius:10px; padding:15px;
      box-shadow:0 10px 34px rgba(0,0,0,.24); font-size:14px;
    }
    .titre{
      display:flex; justify-content:space-between; align-items:center;
      font-size:11px; letter-spacing:.18em; text-transform:uppercase;
      color:#14453D; font-weight:700; margin-bottom:12px;
    }
    .fermer{background:none; border:none; color:#9AA0A8; font-size:18px;
            cursor:pointer; line-height:1; padding:0;}
    .fermer:hover{color:#16181D;}
    .verrouille{font-size:13px; line-height:1.55; color:#5A6069;}
    .raccourcis{display:flex; gap:6px; margin-bottom:8px;}
    .mini{
      flex:1; padding:7px 4px; font-size:11.5px; font-weight:600; cursor:pointer;
      background:#fff; color:#5A6069; border:1px solid #E2DED4; border-radius:5px;
    }
    .mini:hover{background:#EFEDE6; color:#14453D;}
    textarea{
      width:100%; height:92px; resize:vertical; padding:9px 11px;
      border:1px solid #E2DED4; border-radius:6px; background:#fff;
      font-size:13px; line-height:1.5; color:#16181D;
    }
    textarea:focus, select:focus, input:focus{outline:none; border-color:#14453D;}
    .etiquette{
      display:block; font-size:10px; letter-spacing:.16em; text-transform:uppercase;
      color:#9AA0A8; font-weight:700; margin:12px 0 6px;
    }
    select, input{
      width:100%; padding:9px 11px; font-size:13px; color:#16181D;
      border:1px solid #E2DED4; border-radius:6px; background:#fff;
    }
    input{margin-top:6px;}
    .principal{
      width:100%; margin-top:11px; padding:10px; cursor:pointer;
      background:#14453D; color:#F4F1E8; border:none; border-radius:6px;
      font-size:13.5px; font-weight:600;
    }
    .principal:hover{background:#0F3730;}
    .principal:disabled{background:#8FA5A0; cursor:default;}
    .etat{font-size:12px; color:#5A6069; margin-top:8px; min-height:16px;}
    [hidden]{display:none !important;}
  </style>`;

  const GABARIT = `
    <div class="zone">
      <div class="panneau" id="panneau" hidden>
        <div class="titre"><span>Sauver dans Kofr</span>
          <button class="fermer" id="fermer">&times;</button></div>

        <div class="verrouille" id="verrouille" hidden>
          Votre coffre est verrouillé. Ouvrez Kofr depuis la barre du
          navigateur et entrez votre phrase — puis revenez ici.
        </div>

        <div id="corps" hidden>
          <div class="raccourcis">
            <button class="mini" id="prendreSelection">Ce que j'ai surligné</button>
            <button class="mini" id="prendreReponse">La dernière réponse</button>
          </div>
          <textarea id="texte" placeholder="Ce que vous voulez garder…"></textarea>
          <label class="etiquette">Ranger dans</label>
          <select id="projet"></select>
          <input id="nouveau" hidden placeholder="Nom du nouveau projet">
          <button class="principal" id="ranger">Ranger dans le coffre</button>
          <div class="etat" id="etat"></div>
        </div>
      </div>
      <button class="pastille" id="pastille" title="Sauver dans Kofr">K</button>
    </div>`;

  function demanderAuFond(message) {
    return new Promise(function (r) {
      try {
        chrome.runtime.sendMessage(message, function (reponse) {
          if (chrome.runtime.lastError) return r(null);
          r(reponse || null);
        });
      } catch (e) { r(null); }
    });
  }

  function texteSurligne() {
    try { return (window.getSelection().toString() || "").trim(); }
    catch (e) { return ""; }
  }

  function derniereReponse() {
    const r = reponsesIA();
    if (!r.length) return "";
    return (r[r.length - 1].innerText || "").trim();
  }

  function installerBouton() {
    const ancien = document.getElementById(ID_HOTE);
    if (ancien) ancien.remove();            // une génération précédente

    const hote = document.createElement("div");
    hote.id = ID_HOTE;
    // Ancré en bas à droite, sans surface propre : il ne peut donc
    // rien recouvrir ni décaler dans la page de l'IA.
    hote.setAttribute("style",
      "position:fixed; right:0; bottom:0; width:0; height:0; " +
      "z-index:2147483000; margin:0; padding:0; border:0;");
    const racine = hote.attachShadow({ mode: "open" });
    racine.innerHTML = STYLE + GABARIT;
    (document.body || document.documentElement).appendChild(hote);

    const $ = function (id) { return racine.getElementById(id); };
    const panneau = $("panneau");

    // La pastille se met en évidence dès qu'un texte est surligné :
    // c'est le moment où l'on a quelque chose à garder.
    document.addEventListener("selectionchange", function () {
      if (perime()) return;
      $("pastille").classList.toggle("pret", texteSurligne().length > 2);
    });

    async function ouvrirPanneau() {
      panneau.hidden = false;
      $("etat").textContent = "";
      $("corps").hidden = true;
      $("verrouille").hidden = true;

      const surligne = texteSurligne();

      const etat = await demanderAuFond({ kofr: "etat" });
      if (!etat || !etat.ouvert) { $("verrouille").hidden = false; return; }

      const choix = $("projet");
      choix.innerHTML = "";
      const options = [["", "Sans projet"]]
        .concat((etat.projets || []).map(function (p) { return [p, p]; }));
      options.push(["__neuf__", "＋ Nouveau projet…"]);
      options.forEach(function (o) {
        const opt = document.createElement("option");
        opt.value = o[0];
        opt.textContent = o[1];
        choix.appendChild(opt);
      });

      $("nouveau").hidden = true;
      $("nouveau").value = "";
      $("texte").value = surligne;
      $("corps").hidden = false;
      $("texte").focus();
    }

    $("pastille").addEventListener("click", function () {
      if (panneau.hidden) ouvrirPanneau();
      else panneau.hidden = true;
    });

    $("fermer").addEventListener("click", function () { panneau.hidden = true; });

    $("prendreSelection").addEventListener("click", function () {
      const t = texteSurligne();
      if (t) $("texte").value = t;
      else $("etat").textContent = "Rien n'est surligné dans la page.";
    });

    $("prendreReponse").addEventListener("click", function () {
      const t = derniereReponse();
      if (t) $("texte").value = t;
      else $("etat").textContent = "Aucune réponse trouvée sur cette page.";
    });

    $("projet").addEventListener("change", function () {
      const neuf = $("projet").value === "__neuf__";
      $("nouveau").hidden = !neuf;
      if (neuf) $("nouveau").focus();
    });

    $("ranger").addEventListener("click", async function () {
      const texte = $("texte").value.trim();
      if (!texte) { $("etat").textContent = "Il n'y a rien à ranger."; return; }

      const projet = $("projet").value === "__neuf__"
        ? $("nouveau").value.trim()
        : $("projet").value;

      $("ranger").disabled = true;
      $("etat").textContent = "Chiffrement…";

      const r = await demanderAuFond({ kofr: "ranger", texte: texte, projet: projet });

      $("ranger").disabled = false;

      if (r && r.ok) {
        $("etat").textContent = "Rangé dans votre coffre.";
        setTimeout(function () { panneau.hidden = true; }, 1200);
      } else if (r && r.raison === "verrouille") {
        $("corps").hidden = true;
        $("verrouille").hidden = false;
      } else {
        $("etat").textContent = "Échec — le coffre n'a pas répondu.";
      }
    });
  }

  installerBouton();

})();
