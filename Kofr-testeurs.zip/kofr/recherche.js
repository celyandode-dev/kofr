// ---------------------------------------------------------------
// Kofr — recherche.js
//
// Trouver le bon souvenir sans que le serveur puisse chercher.
// Tout se passe ici, sur l'ordinateur de l'utilisateur.
//
// Principe : on ne FILTRE jamais, on TRIE. Un filtre qui se trompe
// fait disparaître un souvenir ; un tri qui se trompe le met juste
// plus bas dans la liste.
// ---------------------------------------------------------------

// Des familles de mots qui parlent de la même chose.
// « immobilier » doit attraper « maison », « loyer », « notaire »…
const FAMILLES = [
  ["immobilier", "immo", "maison", "appartement", "appart", "logement", "bien",
   "achat", "acheter", "vente", "vendre", "location", "louer", "loyer", "agence",
   "proprietaire", "locataire", "terrain", "villa", "studio", "copropriete",
   "syndic", "notaire", "bail", "hypotheque", "credit immobilier", "chalet"],

  ["travail", "boulot", "job", "emploi", "metier", "entreprise", "boite",
   "bureau", "collegue", "patron", "salaire", "carriere", "stage", "alternance",
   "apprentissage", "contrat", "mission", "client", "projet"],

  ["etudes", "ecole", "universite", "fac", "cours", "diplome", "examen",
   "bts", "licence", "master", "bachelor", "formation", "prof", "professeur",
   "revision", "semestre", "etudiant"],

  ["famille", "parents", "pere", "mere", "papa", "maman", "frere", "soeur",
   "enfant", "fils", "fille", "cousin", "oncle", "tante", "grand-mere",
   "grand-pere", "mariage", "couple", "conjoint"],

  ["sport", "entrainement", "muscu", "musculation", "salle", "course", "courir",
   "foot", "velo", "natation", "marathon", "gym", "fitness", "ski", "randonnee"],

  ["argent", "budget", "epargne", "investissement", "investir", "banque",
   "credit", "pret", "impot", "revenu", "depense", "economie", "finance",
   "bourse", "patrimoine"],

  ["voyage", "vacances", "hotel", "avion", "train", "destination", "sejour",
   "vol", "reservation", "tourisme", "week-end"],

  ["cuisine", "manger", "repas", "recette", "restaurant", "regime", "plat",
   "alimentation", "midi", "diner", "courses"],

  ["technique", "informatique", "ordinateur", "logiciel", "code", "coder",
   "developpement", "application", "site", "internet", "programmation", "web"],

  ["loisirs", "musique", "film", "serie", "livre", "jeu", "lecture", "concert",
   "cinema", "sortie", "soiree"]
];

function normaliserMot(t) {
  return t.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
}

// Ramène un mot à son début, pour que « immobilier » et « immobilière »
// se reconnaissent. Grossier, mais efficace en français.
function racine(mot) {
  const m = normaliserMot(mot);
  return m.length > 6 ? m.slice(0, m.length - 2) : m;
}

// À quelles familles appartient ce mot ?
function famillesDe(mot) {
  const m = normaliserMot(mot);
  const trouvees = [];
  FAMILLES.forEach(function (famille, index) {
    for (let i = 0; i < famille.length; i++) {
      if (famille[i].includes(m) || m.includes(famille[i])) {
        trouvees.push(index);
        return;
      }
    }
  });
  return trouvees;
}

// --- LE SCORE ----------------------------------------------------
// 3 points : le mot est là tel quel
// 2 points : la racine correspond (immobilier / immobilière)
// 1 point  : même famille de sens (immobilier / maison)
function scorePertinence(souvenir, motsRecherches) {
  const texte = normaliserMot(souvenir);
  const motsTexte = texte.split(/[^a-z0-9]+/).filter(Boolean);

  let score = 0;

  motsRecherches.forEach(function (mot) {
    if (mot.length < 3) return;

    if (texte.includes(normaliserMot(mot))) {
      score += 3;
      return;
    }

    const r = racine(mot);
    if (r.length >= 4 && motsTexte.some(function (m) { return m.startsWith(r); })) {
      score += 2;
      return;
    }

    const fam = famillesDe(mot);
    if (fam.length) {
      const touche = motsTexte.some(function (m) {
        return famillesDe(m).some(function (f) { return fam.includes(f); });
      });
      if (touche) score += 1;
    }
  });

  return score;
}

// --- LE CLASSEMENT -----------------------------------------------
// Renvoie TOUT le coffre, trié. Rien ne disparaît jamais.
function classer(souvenirs, sujet) {
  const mots = normaliserMot(sujet).split(/\s+/).filter(Boolean);

  if (!mots.length) {
    return souvenirs.map(function (s) { return { texte: s, score: 0 }; });
  }

  return souvenirs
    .map(function (s) { return { texte: s, score: scorePertinence(s, mots) }; })
    .sort(function (a, b) { return b.score - a.score; });
}
