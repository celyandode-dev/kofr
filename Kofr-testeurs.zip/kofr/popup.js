// ---------------------------------------------------------------
// Kofr — popup.js  (version 0.5 — le coffre a une serrure)
//
// Deux protections, à ne pas confondre :
//   - le CHIFFREMENT protège le contenu (personne ne peut lire)
//   - le JETON protège la porte      (personne ne peut écrire)
// ---------------------------------------------------------------

const COFFRE = "https://kofr-coffre.celyandode.workers.dev";

// Les deux vivent uniquement en mémoire, le temps que la fenêtre est ouverte.
let cle = null;
let jeton = null;
let compte = null;

const ecranVerrou   = document.getElementById("ecranVerrou");
const ecranCoffre   = document.getElementById("ecranCoffre");
const identifiant   = document.getElementById("identifiant");
const phrase        = document.getElementById("phrase");
const erreurVerrou  = document.getElementById("erreurVerrou");
const deverrouiller = document.getElementById("deverrouiller");
const verrouiller   = document.getElementById("verrouiller");
const saisie        = document.getElementById("saisie");
const bouton        = document.getElementById("bouton");
const liste         = document.getElementById("liste");
const vide          = document.getElementById("vide");

// Chaque demande au coffre présente le jeton.
function entetes(avecJson) {
  const h = { "X-Kofr-Jeton": jeton, "X-Kofr-Compte": compte };
  if (avecJson) h["Content-Type"] = "application/json";
  return h;
}

// --- OUVRIR LE COFFRE -------------------------------------------
deverrouiller.addEventListener("click", async () => {
  if (!phrase.value || !identifiant.value.trim()) return;

  erreurVerrou.classList.add("cache");
  deverrouiller.disabled = true;
  deverrouiller.textContent = "Fabrication des clés…";

  const c = await identifiantCompte(identifiant.value);
  const sel = await obtenirSel(COFFRE, c);
  const cles = await fabriquerCles(phrase.value, sel);

  // On frappe à la porte AVANT d'ouvrir l'écran.
  const test = await fetch(COFFRE + "/notes", {
    headers: { "X-Kofr-Jeton": cles.jeton, "X-Kofr-Compte": c }
  });

  deverrouiller.disabled = false;
  deverrouiller.textContent = "Ouvrir le coffre";

  // RÈGLE : on n'ouvre QUE sur un succès franc.
  // Tout le reste — refus, blocage, panne, serveur injoignable —
  // laisse le coffre fermé. C'est le sens par défaut le plus sûr.
  if (!test.ok) {
    erreurVerrou.textContent =
      test.status === 429
        ? "Trop de tentatives. Réessayez dans 15 minutes."
        : "Phrase incorrecte.";
    erreurVerrou.classList.remove("cache");
    phrase.value = "";
    return;
  }

  cle = cles.cle;
  jeton = cles.jeton;
  compte = c;
  phrase.value = "";

  // On retient l'identifiant — jamais la phrase.
  chrome.storage.local.set({ kofrIdentifiant: identifiant.value.trim() });
  await memoriserSession();

  await ouvrirLeCoffre();
});

// Tout ce qui suit l'ouverture, qu'elle vienne d'une phrase tapée
// ou d'une session déjà déverrouillée.
async function ouvrirLeCoffre() {
  ecranAccueil.classList.add("cache");
  ecranVerrou.classList.add("cache");
  ecranCoffre.classList.remove("cache");

  await charger();
  await chargerRemplacements();
  await chargerReglageMasquage();
  await chargerChoixIA();
  await chargerReglageTemporaire();
  await verifierResumeEnAttente();

  // Un coffre vraiment vide n'a qu'un seul usage : être rempli.
  // On regarde le coffre entier, pas la liste affichée à l'écran :
  // sur la vue des projets, celle-ci est vide par construction.
  if (!toutesNotes.length && !projetsVides.length) {
    document.getElementById("titreImport").textContent =
      "Commençons par récupérer ce que ChatGPT sait de vous";
    ecranCoffre.classList.add("cache");
    ecranImport.classList.remove("cache");
  }
}

phrase.addEventListener("keydown", (e) => {
  if (e.key === "Enter") deverrouiller.click();
});

// --- REFERMER LE COFFRE -----------------------------------------
verrouiller.addEventListener("click", async () => {
  await oublierSession();
  cle = null;                       // tout disparaît de la mémoire
  jeton = null;
  compte = null;
  projetOuvert = null;
  toutesNotes = [];
  liste.innerHTML = "";
  ecranCoffre.classList.add("cache");
  ecranVerrou.classList.remove("cache");
});

function etat(message) {
  vide.textContent = message;
  vide.style.display = "block";
  if (typeof videProjets !== "undefined" && videProjets) {
    videProjets.textContent = message;
    videProjets.style.display = "block";
  }
}

// --- JETER UNE NOTE ---------------------------------------------
async function jeter(id) {
  await fetch(COFFRE + "/note/" + id, { method: "DELETE", headers: entetes(false) });
  await charger();
}

// --- CONSTRUIRE UNE LIGNE ---------------------------------------
function fabriquerLigne(n) {
  const ligne = document.createElement("li");

  const contenu = document.createElement("div");
  contenu.className = "contenu";

  if (n.date) {
    const quand = document.createElement("span");
    quand.className = "date-note";
    quand.textContent = jourLisible(n.date);
    contenu.appendChild(quand);
  }

  const corps = document.createElement("span");
  if (n.texte === null) {
    corps.textContent = "Note illisible avec cette phrase";
    ligne.className = "illisible";
  } else {
    corps.textContent = n.texte;
  }
  contenu.appendChild(corps);
  ligne.appendChild(contenu);

  // Les toutes premières notes n'ont pas de numéro : pas de croix.
  if (n.id) {
    const croix = document.createElement("button");
    croix.className = "supprimer";
    croix.textContent = "×";
    croix.title = "Retirer du coffre";
    croix.addEventListener("click", () => jeter(n.id));
    ligne.appendChild(croix);
  }

  return ligne;
}

// --- LIRE LE COFFRE ----------------------------------------------
// On ouvre TOUTES les boîtes une seule fois, ici, sur ton ordinateur.
// Ensuite on affiche : soit la liste des projets, soit l'un d'eux.
async function charger() {
  try {
    etat("Ouverture du coffre…");
    await chargerProjetsVides();
    const reponse = await fetch(COFFRE + "/notes", { headers: entetes(false) });
    const data = await reponse.json();
    const notes = data.notes || [];

    toutesNotes = [];
    for (const note of notes) {
      const ouvert = await dechiffrerNote(note.texte, cle);
      toutesNotes.push({
        id: note.id,
        dossier: ouvert ? ouvert.dossier : "",
        texte: ouvert ? ouvert.texte : null,
        date: ouvert ? ouvert.date : ""
      });
    }

    majListeDossiers();
    if (projetOuvert === null) afficherProjets();
    else afficherHistorique();
  } catch (e) {
    etat("Coffre injoignable. Vérifie ta connexion.");
  }
}

// --- ÉCRIRE DANS LE COFFRE ---------------------------------------
bouton.addEventListener("click", async () => {
  const texte = saisie.value.trim();
  if (!texte || !cle) return;

  bouton.disabled = true;
  bouton.textContent = "Chiffrement…";

  try {
    // On ferme la boîte AVANT que quoi que ce soit ne parte.
    const paquet = await chiffrerNote(projetOuvert || "", texte, cle);

    await fetch(COFFRE + "/note", {
      method: "POST",
      headers: entetes(true),
      body: JSON.stringify({ texte: paquet })
    });

    saisie.value = "";
    if (projetOuvert && projetsVides.includes(projetOuvert)) {
      projetsVides = projetsVides.filter((p) => p !== projetOuvert);
      await sauverProjetsVides();
    }
    await charger();
  } catch (e) {
    etat("Échec de l'envoi.");
  }

  bouton.disabled = false;
  bouton.textContent = "Ranger dans ce projet";
});

saisie.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") bouton.click();
});

// ================================================================
// IMPORT DEPUIS CHATGPT
// ================================================================

const ouvrirImport = document.getElementById("ouvrirImport");
const ecranImport  = document.getElementById("ecranImport");
const promptTexte  = document.getElementById("promptTexte");
const copierPrompt = document.getElementById("copierPrompt");
const colle        = document.getElementById("colle");
const analyser     = document.getElementById("analyser");
const zoneApercu   = document.getElementById("zoneApercu");
const compteur     = document.getElementById("compteur");
const apercu       = document.getElementById("apercu");
const importer     = document.getElementById("importer");
const retour       = document.getElementById("retour");

// Dans quel projet ira ce qu'on va récupérer. "" = sans projet.
let destinationRecuperation = "";

// Aller à l'écran d'import et en revenir.
ouvrirImport.addEventListener("click", () => {
  document.getElementById("titreImport").textContent = "Remplir votre coffre";
  destinationRecuperation = "";
  dossierImport.value = "";
  ecranCoffre.classList.add("cache");
  ecranImport.classList.remove("cache");
});

retour.addEventListener("click", async () => {
  ecranImport.classList.add("cache");
  ecranCoffre.classList.remove("cache");
  colle.value = "";
  zoneApercu.classList.add("cache");
  await charger();
});

copierPrompt.addEventListener("click", () => {
  navigator.clipboard.writeText(promptTexte.textContent.trim());
  copierPrompt.textContent = "Copié";
  setTimeout(() => (copierPrompt.textContent = "Copier ce message"), 1500);
});

// --- DÉCOUPER LA RÉPONSE ----------------------------------------
// ChatGPT répond en vrac. On coupe ligne par ligne et on nettoie
// les puces, tirets et numéros qu'il met devant.
function decouper(brut) {
  return brut
    .split("\n")
    .map((l) => l.replace(/^\s*[-•*–—]\s*/, "").replace(/^\s*\d+[.)]\s*/, "").trim())
    .filter((l) => l.length > 3);
}

// --- APERÇU AVEC CASES À COCHER ---------------------------------
// RIEN n'entre dans le coffre sans que tu l'aies validé.
function remplirApercu(lignes, toutCoche) {
  apercu.innerHTML = "";
  lignes.forEach((texte) => {
    const li = document.createElement("li");

    const case_ = document.createElement("input");
    case_.type = "checkbox";
    case_.checked = toutCoche;

    const contenu = document.createElement("div");
    contenu.className = "contenu";
    contenu.textContent = texte;

    li.appendChild(case_);
    li.appendChild(contenu);
    apercu.appendChild(li);
  });

  compteur.textContent =
    lignes.length + " information" + (lignes.length > 1 ? "s" : "") +
    " trouvée" + (lignes.length > 1 ? "s" : "") +
    (toutCoche
      ? ". Décochez ce que vous ne voulez pas garder."
      : ". Cochez celles que vous voulez garder.");

  zoneApercu.classList.remove("cache");
}

analyser.addEventListener("click", () => {
  remplirApercu(decouper(colle.value), true);
});

// --- LE FICHIER D'EXPORT CHATGPT --------------------------------
// Des milliers de messages : on ne coche RIEN par défaut.
// C'est à l'utilisateur de choisir, pas à nous de deviner.
const fichierExport = document.getElementById("fichierExport");

fichierExport.addEventListener("change", async () => {
  const fichier = fichierExport.files[0];
  if (!fichier) return;

  compteur.textContent = "Lecture du fichier…";
  zoneApercu.classList.remove("cache");
  apercu.innerHTML = "";

  try {
    const donnees = JSON.parse(await fichier.text());
    if (!Array.isArray(donnees)) throw new Error("format");

    const faits = extraireFaits(donnees, 150);
    if (!faits.length) {
      compteur.textContent = "Aucune phrase personnelle trouvée dans ce fichier.";
      return;
    }
    remplirApercu(faits, false);
  } catch (e) {
    compteur.textContent =
      "Fichier illisible. Attendu : conversations.json, extrait du zip d'export ChatGPT.";
  }
});

// --- RANGER LA SÉLECTION ----------------------------------------
importer.addEventListener("click", async () => {
  const retenues = [];
  apercu.querySelectorAll("li").forEach((li) => {
    if (li.querySelector("input").checked) {
      retenues.push(li.querySelector(".contenu").textContent);
    }
  });
  if (!retenues.length || !cle) return;

  importer.disabled = true;

  for (let i = 0; i < retenues.length; i++) {
    importer.textContent = "Chiffrement… " + (i + 1) + "/" + retenues.length;
    const paquet = await chiffrerNote(dossierImport.value.trim(), retenues[i], cle);
    await fetch(COFFRE + "/note", {
      method: "POST",
      headers: entetes(true),
      body: JSON.stringify({ texte: paquet })
    });
  }

  importer.disabled = false;
  importer.textContent = "Ranger la sélection";

  // On atterrit dans le projet où l'on vient de ranger.
  projetOuvert = dossierImport.value.trim();

  colle.value = "";
  zoneApercu.classList.add("cache");
  ecranImport.classList.add("cache");
  ecranCoffre.classList.remove("cache");
  await charger();
});

// ================================================================
// PRÉPARER LE CONTEXTE POUR UNE IA
//
// Le point clé : la recherche se fait ICI, sur ton ordinateur.
// Le serveur ne peut pas chercher — il ne voit que du chiffré.
// C'est une contrainte, et c'est aussi ce qui rend le produit unique.
// ================================================================

const ouvrirPreparer    = document.getElementById("ouvrirPreparer");
const ecranPreparer     = document.getElementById("ecranPreparer");
const sujet             = document.getElementById("sujet");
const chercher          = document.getElementById("chercher");
const zoneResultats     = document.getElementById("zoneResultats");
const compteurResultats = document.getElementById("compteurResultats");
const resultats         = document.getElementById("resultats");
const copierContexte    = document.getElementById("copierContexte");
const confirmCopie      = document.getElementById("confirmCopie");
const retourPreparer    = document.getElementById("retourPreparer");

ouvrirPreparer.addEventListener("click", () => {
  filtreDossier.value = "";
  ecranCoffre.classList.add("cache");
  ecranPreparer.classList.remove("cache");
  sujet.focus();
});

retourPreparer.addEventListener("click", () => {
  ecranPreparer.classList.add("cache");
  ecranCoffre.classList.remove("cache");
  sujet.value = "";
  zoneResultats.classList.add("cache");
  confirmCopie.style.display = "none";
});

// --- CHERCHER ----------------------------------------------------
// On ne filtre pas : on trie. Tout le coffre reste visible, les
// souvenirs pertinents remontent et arrivent déjà cochés.
chercher.addEventListener("click", async () => {
  if (!cle) return;

  chercher.disabled = true;
  chercher.textContent = "Ouverture des boîtes…";

  // On récupère tout, et on déchiffre tout — chez toi.
  const reponse = await fetch(COFFRE + "/notes", { headers: entetes(false) });
  const data = await reponse.json();
  const notes = data.notes || [];

  const clairs = [];
  for (const note of notes) {
    const ouvert = await dechiffrerNote(note.texte, cle);
    if (!ouvert) continue;
    if (filtreDossier.value && ouvert.dossier !== filtreDossier.value) continue;
    clairs.push(ouvert.texte);
  }

  chercher.disabled = false;
  chercher.textContent = "Chercher dans le coffre";

  const classes = classer(clairs, sujet.value);
  const pertinents = classes.filter(function (x) { return x.score > 0; }).length;

  resultats.innerHTML = "";
  classes.forEach((item) => {
    const li = document.createElement("li");

    const case_ = document.createElement("input");
    case_.type = "checkbox";
    case_.checked = item.score > 0;      // le pertinent arrive coché
    li.dataset.pertinent = item.score > 0 ? "1" : "0";

    const contenu = document.createElement("div");
    contenu.className = "contenu";
    contenu.textContent = item.texte;

    li.appendChild(case_);
    li.appendChild(contenu);
    resultats.appendChild(li);
  });

  if (!classes.length) {
    compteurResultats.textContent = "Votre coffre est vide.";
  } else if (!sujet.value.trim()) {
    compteurResultats.textContent =
      classes.length + " information" + (classes.length > 1 ? "s" : "") +
      " dans le coffre. Cochez ce que l'IA doit savoir.";
  } else if (pertinents) {
    compteurResultats.textContent =
      pertinents + " information" + (pertinents > 1 ? "s" : "") +
      " sur ce sujet, cochée" + (pertinents > 1 ? "s" : "") +
      ". Le reste du coffre est en dessous.";
  } else {
    compteurResultats.textContent =
      "Rien trouvé sur ce sujet — voici tout le coffre, à vous de cocher.";
  }

  confirmCopie.style.display = "none";
  zoneResultats.classList.remove("cache");

  document.querySelectorAll(".niveau").forEach((b) => b.classList.remove("actif"));
  const complet = document.querySelector('.niveau[data-n="0"]');
  if (complet) complet.classList.add("actif");
  majEnvoi();
});

sujet.addEventListener("keydown", (e) => {
  if (e.key === "Enter") chercher.click();
});

// --- COPIER LE CONTEXTE ------------------------------------------
copierContexte.addEventListener("click", () => {
  const lignes = [];
  resultats.querySelectorAll("li").forEach((li) => {
    if (li.querySelector("input").checked) {
      lignes.push("- " + li.querySelector(".contenu").textContent);
    }
  });
  if (!lignes.length) return;

  const brut =
    "Voici ce que tu dois savoir de moi pour cette conversation :\n" +
    lignes.join("\n");

  viserEnvoi(ecranPreparer, copierContexte, "Copier pour coller ailleurs");
  preparerEnvoi(brut, async (bloc) => {
    ecranNoms.classList.add("cache");
    ecranPreparer.classList.remove("cache");
    navigator.clipboard.writeText(bloc);
    confirmCopie.style.display = "block";
  });
});

// ================================================================
// ENVOI DIRECT DANS CHATGPT
//
// Ici l'extension sort de sa fenêtre : elle va écrire dans la page
// de ChatGPT. C'est pour ça que le navigateur exige une permission
// explicite sur ce site, déclarée dans manifest.json.
// ================================================================

const envoyerChatGPT = document.getElementById("envoyerChatGPT");

// Rassemble les lignes cochées en un seul bloc.
function blocContexte() {
  const lignes = [];
  resultats.querySelectorAll("li").forEach((li) => {
    if (li.querySelector("input").checked) {
      lignes.push("- " + li.querySelector(".contenu").textContent);
    }
  });
  if (!lignes.length) return null;
  return (
    "Voici ce que tu dois savoir de moi pour cette conversation :\n" +
    lignes.join("\n")
  );
}

envoyerChatGPT.addEventListener("click", async () => {
  const brut = blocContexte();
  if (!brut) return;
  viserEnvoi(ecranPreparer, envoyerChatGPT, "Envoyer dans mon IA");
  await preparerEnvoi(brut, envoyerVraiment);
});

// Envoyée dans la page de ChatGPT, elle s'exécute LÀ-BAS. Elle ne
// peut donc utiliser aucune variable de ce fichier — et elle survit
// à la fermeture de cette fenêtre, ce qui est tout l'intérêt.
function collerDansLaPage(texte) {
  const trouver = function () {
    return (
      document.querySelector("#prompt-textarea") ||
      document.querySelector('div[contenteditable="true"]') ||
      document.querySelector("textarea")
    );
  };

  const ecrire = function (cible) {
    cible.focus();
    if (cible.tagName === "TEXTAREA") {
      const setter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype, "value"
      ).set;
      setter.call(cible, texte + "\n\n");
      cible.dispatchEvent(new Event("input", { bubbles: true }));
    } else {
      document.execCommand("insertText", false, texte + "\n\n");
    }
    cible.focus();
  };

  // La page peut mettre quelques secondes à se dessiner, surtout si
  // l'onglet dormait. On guette la zone de saisie sans bloquer.
  let restant = 40;
  const essayer = function () {
    const cible = trouver();
    if (cible) { ecrire(cible); return; }
    if (--restant > 0) setTimeout(essayer, 250);
  };
  essayer();
}

// L'ONGLET D'ABORD, LE TEXTE ENSUITE.
//
// Leçon apprise : cette fenêtre meurt dès qu'on change d'onglet.
// On ne peut donc RIEN attendre ici. On envoie le travail dans la
// page, où il continuera tout seul, et on s'efface.
async function envoyerVraiment(bloc) {
  ecranNoms.classList.add("cache");
  (ecranRetourEnvoi || ecranPreparer).classList.remove("cache");
  if (!boutonEnvoi) viserEnvoi(ecranPreparer, envoyerChatGPT, "Envoyer dans mon IA");
  boutonEnvoi.disabled = true;
  boutonEnvoi.textContent = "Ouverture de " + siteParCle(iaChoisie).nom + "…";

  // FILET DE SÉCURITÉ : on copie d'abord, on ouvre ensuite.
  // Si le collage automatique rate, il reste Ctrl+V.
  try { await navigator.clipboard.writeText(bloc); } catch (e) {}

  try {
    const onglet = await ongletPourEcrire();

    if (onglet) {
      // On ne l'attend pas : elle travaille dans la page, pas ici.
      chrome.scripting.executeScript({
        target: { tabId: onglet.id },
        func: collerDansLaPage,
        args: [bloc]
      }).catch(function () {});

      await chrome.tabs.update(onglet.id, { active: true });
      try { await chrome.windows.update(onglet.windowId, { focused: true }); } catch (e) {}
    } else {
      // Onglet neuf : le texte est déposé AVANT, pour que le
      // résident le trouve en s'installant au chargement.
      await chrome.storage.local.set({ kofrColler: { texte: bloc } });
      const neuf = await chrome.tabs.create({ url: adresseAOuvrir(), active: true });
      await retenirOngletTemporaire(neuf);
    }

    window.close();          // le travail est passé de l'autre côté
  } catch (e) {
    const b = boutonEnvoi, libelle = libelleEnvoi;
    b.textContent = "Copié — collez avec Ctrl+V";
    setTimeout(() => (b.textContent = libelle), 5000);
    boutonEnvoi.disabled = false;
  }
}

// ================================================================
// RÉCUPÉRER UNE CONVERSATION
//
// L'extension demande à l'IA de résumer ce qu'elle a appris sur
// l'utilisateur, LIT sa réponse dans la page, et la propose au
// tri. Rien n'entre dans le coffre sans validation.
// ================================================================

const recupererConv = document.getElementById("recupererConv");

function rendreBoutonSauver() {
  recupererConv.innerHTML = "Sauver<br><small>cette conversation</small>";
}

// Une SEULE ligne : dans la zone de saisie de ChatGPT, un saut de
// ligne déclenche l'envoi. Le message partirait en morceaux.
const DEMANDE_RESUME =
  "Liste ce qu'il faut retenir de cette conversation me concernant, ainsi que " +
  "l'avancement de ce sur quoi nous avons travaille. Regles strictes : " +
  "une information par ligne dans ta reponse, sans introduction, sans conclusion, " +
  "sans numerotation ; CONSERVE tous les details concrets — chiffres, montants, " +
  "dates, noms, lieux, decisions prises, options ecartees et la raison ; " +
  "ne generalise pas, ecris \"budget de 340 000 euros\" et non \"un budget defini\" ; " +
  "inclus aussi bien les faits sur moi que l'etat d'avancement du travail ; " +
  "chaque ligne doit se suffire a elle-meme, comprehensible hors contexte. " +
  "Si tu n'as rien a retenir, reponds uniquement : RIEN.";

recupererConv.addEventListener("click", async () => {
  recupererConv.disabled = true;
  // Depuis la liste des projets, la destination n'est pas choisie.
  if (projetOuvert === null) destinationRecuperation = "";

  const onglets = await chrome.tabs.query({ url: TOUS_MOTIFS });

  if (!onglets.length) {
    recupererConv.textContent = "Ouvrez d'abord une IA";
    setTimeout(() => {
      rendreBoutonSauver();
      recupererConv.disabled = false;
    }, 3000);
    return;
  }

  // On dépose la tâche. Le résident installé dans la page la voit
  // et s'en charge — même si la page recharge entre-temps.
  // On installe le résident nous-mêmes dans l'onglet.
  // Sans ça, une page ouverte AVANT l'extension n'en a jamais reçu,
  // et personne n'est là pour lire la réponse. On ne peut pas
  // demander à quelqu'un de penser à recharger sa page.
  try {
    await chrome.scripting.executeScript({
      target: { tabId: onglets[0].id },
      files: ["content.js"]
    });
  } catch (e) {
    // Déjà présent : il refusera poliment, ce n'est pas grave.
  }

  await chrome.storage.local.set({
    kofrTache: { etat: "a_envoyer", demande: DEMANDE_RESUME },
    kofrDestination: destinationRecuperation || ""
  });

  recupererConv.textContent = "Appuyez sur Entrée dans l’IA";
  setTimeout(() => {
    rendreBoutonSauver();
    recupererConv.disabled = false;
  }, 4000);
});

// --- AU RETOUR ---------------------------------------------------
// À chaque ouverture du coffre, on regarde où en est le résident.
async function verifierResumeEnAttente() {
  const data = await chrome.storage.local.get(["kofrTache", "kofrDestination"]);
  const t = data.kofrTache;
  destinationRecuperation = data.kofrDestination || "";
  if (!t) return;

  if (t.etat === "a_envoyer") {
    recupererConv.textContent = "Appuyez sur Entrée dans l’IA";
    return;
  }
  if (t.etat === "attente") {
    recupererConv.textContent = "Lecture en cours…";
    return;
  }

  await chrome.storage.local.remove("kofrTache");

  if (t.etat === "echec") {
    recupererConv.textContent = "Échec : " + (t.raison || "inconnu");
    return;
  }

  if (t.etat === "fini" && t.texte) {
    if (t.texte.trim().toUpperCase().startsWith("RIEN")) {
      recupererConv.textContent = "Rien de nouveau sur vous";
      setTimeout(() => (rendreBoutonSauver()), 3000);
      return;
    }
    ecranCoffre.classList.add("cache");
    ecranImport.classList.remove("cache");
    dossierImport.value = destinationRecuperation || "";
    remplirApercu(decouper(t.texte), true);
  }
}

// ================================================================
// NIVEAUX DE DÉTAIL
//
// Le compteur est le vrai sujet : il rend visible ce qu'on
// s'apprête à donner à l'IA. Sans lui, on envoie à l'aveugle.
// ================================================================

const envoiResume = document.getElementById("envoiResume");

// Met à jour « X informations · ~Y mots » à chaque changement.
function majEnvoi() {
  const cochees = [];
  resultats.querySelectorAll("li").forEach((li) => {
    if (li.querySelector("input").checked) {
      cochees.push(li.querySelector(".contenu").textContent);
    }
  });

  if (!cochees.length) {
    envoiResume.textContent = "Rien de sélectionné.";
    return;
  }

  const mots = cochees.join(" ").split(/\s+/).filter(Boolean).length;
  envoiResume.textContent =
    "Vous allez envoyer " + cochees.length +
    " information" + (cochees.length > 1 ? "s" : "") +
    " · environ " + mots + " mots.";
}

// Coche les n premiers (les plus pertinents). 0 = tout ce qui est pertinent.
function appliquerNiveau(n) {
  const lignes = Array.from(resultats.querySelectorAll("li"));

  lignes.forEach((li, index) => {
    const pertinent = li.dataset.pertinent === "1";
    const case_ = li.querySelector("input");
    case_.checked = n === 0 ? pertinent : pertinent && index < n;
  });

  majEnvoi();
}

document.querySelectorAll(".niveau").forEach((bouton) => {
  bouton.addEventListener("click", () => {
    document.querySelectorAll(".niveau").forEach((b) => b.classList.remove("actif"));
    bouton.classList.add("actif");
    appliquerNiveau(parseInt(bouton.dataset.n, 10));
  });
});

// Le compteur suit aussi les cases cochées à la main.
resultats.addEventListener("change", majEnvoi);

// ================================================================
// PREMIÈRE OUVERTURE
//
// Un inconnu ne doit pas tomber sur un formulaire sans savoir
// pourquoi. On lui explique d'abord, on demande ensuite.
// ================================================================

const ecranAccueil = document.getElementById("ecranAccueil");
const commencer = document.getElementById("commencer");

commencer.addEventListener("click", () => {
  ecranAccueil.classList.add("cache");
  ecranVerrou.classList.remove("cache");
  identifiant.focus();
});

// Au démarrage : accueil si on ne connaît pas encore l'utilisateur,
// sinon on va droit au verrou avec l'identifiant déjà rempli.
(async function demarrer() {
  const data = await chrome.storage.local.get("kofrIdentifiant");

  if (data.kofrIdentifiant) identifiant.value = data.kofrIdentifiant;

  // Le coffre est-il resté ouvert depuis tout à l'heure ?
  if (await reprendreSession()) {
    await ouvrirLeCoffre();
    return;
  }

  if (data.kofrIdentifiant) {
    ecranVerrou.classList.remove("cache");
    phrase.focus();
  } else {
    ecranVerrou.classList.add("cache");
    ecranAccueil.classList.remove("cache");
  }
})();

// Raccourci : ouvrir son IA sans quitter Kofr des yeux.
document.getElementById("ouvrirChatGPT").addEventListener("click", async () => {
  const onglet = await ongletPourEcrire();
  if (onglet) {
    await chrome.tabs.update(onglet.id, { active: true });
  } else {
    const neuf = await chrome.tabs.create({ url: adresseAOuvrir(), active: true });
    await retenirOngletTemporaire(neuf);
  }
});

// ================================================================
// AIDE CONTEXTUELLE
// Un petit « i » qui déplie une explication, là où les gens
// bloquent sans oser demander.
// ================================================================

document.querySelectorAll(".info").forEach((bouton) => {
  bouton.addEventListener("click", () => {
    const bulle = document.getElementById(bouton.dataset.aide);
    if (bulle) bulle.classList.toggle("cache");
  });
});

// ================================================================
// MON COMPTE — emporter ses données, ou tout effacer
// ================================================================

const ouvrirCompte       = document.getElementById("ouvrirCompte");
const ecranCompte        = document.getElementById("ecranCompte");
const retourCompte       = document.getElementById("retourCompte");
const exporter           = document.getElementById("exporter");
const supprimerCompte    = document.getElementById("supprimerCompte");
const confirmSuppression = document.getElementById("confirmSuppression");
const confirmerSuppression = document.getElementById("confirmerSuppression");

ouvrirCompte.addEventListener("click", () => {
  ecranCoffre.classList.add("cache");
  ecranCompte.classList.remove("cache");
  confirmSuppression.classList.add("cache");
});

retourCompte.addEventListener("click", async () => {
  ecranCompte.classList.add("cache");
  ecranCoffre.classList.remove("cache");
  await charger();
});

// --- EMPORTER SES DONNÉES ---------------------------------------
// Le fichier contient le clair ET le chiffré avec ses paramètres.
// Sans le sel et les paramètres, un export chiffré serait un caillou :
// c'est l'erreur classique de la portabilité.
exporter.addEventListener("click", async () => {
  if (!cle) return;

  exporter.disabled = true;
  exporter.textContent = "Préparation…";

  try {
    const reponse = await fetch(COFFRE + "/notes", { headers: entetes(false) });
    const data = await reponse.json();
    const notes = data.notes || [];

    const clair = [];
    for (const note of notes) {
      const o = await dechiffrerNote(note.texte, cle);
      clair.push({
        id: note.id, date: (o && o.date) ? o.date : note.date,
        dossier: o ? o.dossier : "",
        texte: o ? o.texte : null,
        lisible: o !== null
      });
    }

    const selReponse = await fetch(COFFRE + "/sel", {
      headers: { "X-Kofr-Compte": compte }
    });
    const selData = await selReponse.json();

    const fichier = {
      produit: "Kofr",
      version_export: 1,
      exporte_le: new Date().toISOString(),
      lisible: clair.map((n) => ({ date: n.date, dossier: n.dossier, texte: n.texte })),
      chiffre: {
        avertissement:
          "Pour rouvrir ces donnees il faut votre phrase secrete, le sel et les parametres ci-dessous.",
        sel: selData.sel,
        derivation: {
          algorithme: "PBKDF2",
          hachage: "SHA-256",
          iterations: 600000,
          longueur_bits: 512,
          usage: "256 premiers bits = cle AES-GCM, 256 suivants = jeton"
        },
        chiffrement: {
          algorithme: "AES-GCM",
          format: "base64(iv) + '.' + base64(donnees_chiffrees)"
        },
        notes: notes
      }
    };

    const blob = new Blob([JSON.stringify(fichier, null, 2)], {
      type: "application/json"
    });
    const lien = document.createElement("a");
    lien.href = URL.createObjectURL(blob);
    lien.download = "kofr-export.json";
    lien.click();
    URL.revokeObjectURL(lien.href);

    await noterCopie();
    rappelCopie.classList.add("cache");
    exporter.textContent = "Téléchargé";
    setTimeout(() => (exporter.textContent = "Télécharger mon coffre"), 2500);
  } catch (e) {
    exporter.textContent = "Échec de l'export";
    setTimeout(() => (exporter.textContent = "Télécharger mon coffre"), 2500);
  }

  exporter.disabled = false;
});


// --- REMETTRE UN COFFRE EN PLACE --------------------------------
//
// L'export était un cul-de-sac : on savait sortir, pas rentrer.
// Un produit dont le seul mode de panne grave est la perte de
// données doit savoir faire le chemin inverse.
//
// On repart de la partie EN CLAIR du fichier, pas de la partie
// chiffrée : elle se rechiffre avec la clé du coffre actuel. Ça
// permet de restaurer même après un changement de phrase secrète,
// et même dans un compte différent.
//
// Tout se passe ici. Le fichier ne quitte pas l'ordinateur.

const fichierRestaurer  = document.getElementById("fichierRestaurer");
const apercuRestaurer   = document.getElementById("apercuRestaurer");
const compteurRestaurer = document.getElementById("compteurRestaurer");
const restaurer         = document.getElementById("restaurer");
const erreurRestaurer   = document.getElementById("erreurRestaurer");

let aRestaurer = [];

function direErreurRestaurer(message) {
  erreurRestaurer.textContent = message;
  erreurRestaurer.classList.remove("cache");
  apercuRestaurer.classList.add("cache");
}

fichierRestaurer.addEventListener("change", async () => {
  const fichier = fichierRestaurer.files[0];
  if (!fichier) return;

  erreurRestaurer.classList.add("cache");
  apercuRestaurer.classList.add("cache");
  aRestaurer = [];

  let contenu;
  try {
    contenu = JSON.parse(await fichier.text());
  } catch (e) {
    return direErreurRestaurer("Ce fichier n'est pas lisible.");
  }

  if (!contenu || contenu.produit !== "Kofr" || !Array.isArray(contenu.lisible)) {
    return direErreurRestaurer("Ce fichier n'est pas un export Kofr.");
  }

  const candidats = contenu.lisible.filter(
    (n) => n && typeof n.texte === "string" && n.texte.trim()
  );

  if (!candidats.length) {
    return direErreurRestaurer("Ce fichier ne contient aucune information lisible.");
  }

  // Ce qui est déjà dans le coffre n'y sera pas remis deux fois.
  const deja = new Set(
    toutesNotes
      .filter((n) => n.texte !== null)
      .map((n) => (n.dossier || "") + " " + n.texte.trim())
  );

  const vus = new Set();
  let doublons = 0;

  candidats.forEach((n) => {
    const dossier = typeof n.dossier === "string" ? n.dossier : "";
    const texte = n.texte.trim();
    const empreinte = dossier + " " + texte;
    if (deja.has(empreinte) || vus.has(empreinte)) { doublons++; return; }
    vus.add(empreinte);
    aRestaurer.push({ dossier: dossier, texte: texte, date: n.date || "" });
  });

  if (!aRestaurer.length) {
    return direErreurRestaurer(
      "Tout ce que contient ce fichier est déjà dans votre coffre."
    );
  }

  const projets = new Set(aRestaurer.map((n) => n.dossier).filter(Boolean));
  const sansProjet = aRestaurer.filter((n) => !n.dossier).length;

  let resume = aRestaurer.length +
    " information" + (aRestaurer.length > 1 ? "s" : "") + " à remettre";
  if (projets.size) {
    resume += " · " + projets.size + " projet" + (projets.size > 1 ? "s" : "");
  }
  if (sansProjet) resume += " · " + sansProjet + " sans projet";
  if (doublons) {
    resume += " · " + doublons + " déjà présente" + (doublons > 1 ? "s" : "") +
      ", ignorée" + (doublons > 1 ? "s" : "");
  }
  if (contenu.exporte_le) {
    const d = new Date(contenu.exporte_le);
    if (!isNaN(d.getTime())) {
      resume += "\nExport du " + d.toLocaleDateString("fr-FR",
        { day: "numeric", month: "long", year: "numeric" });
    }
  }

  compteurRestaurer.style.whiteSpace = "pre-line";
  compteurRestaurer.textContent = resume;
  apercuRestaurer.classList.remove("cache");
});

restaurer.addEventListener("click", async () => {
  if (!aRestaurer.length || !cle) return;

  restaurer.disabled = true;
  let places = 0;

  try {
    for (let i = 0; i < aRestaurer.length; i++) {
      restaurer.textContent = "Chiffrement… " + (i + 1) + "/" + aRestaurer.length;

      const n = aRestaurer[i];
      // On garde la date d'origine : un historique de projet remis
      // dans le désordre ne vaut rien.
      const paquet = await chiffrer(JSON.stringify({
        d: n.dossier,
        t: n.texte,
        j: n.date || new Date().toISOString()
      }), cle);

      const r = await fetch(COFFRE + "/note", {
        method: "POST",
        headers: entetes(true),
        body: JSON.stringify({ texte: paquet })
      });
      if (!r.ok) throw new Error("refus du serveur");
      places++;
    }

    restaurer.textContent = places + " remise" + (places > 1 ? "s" : "") + " en place";
    aRestaurer = [];
    fichierRestaurer.value = "";
    await charger();
    setTimeout(() => {
      apercuRestaurer.classList.add("cache");
      restaurer.textContent = "Restaurer dans mon coffre";
    }, 2500);
  } catch (e) {
    direErreurRestaurer(
      "Interrompu après " + places + " information" + (places > 1 ? "s" : "") +
      ". Vous pouvez relancer : ce qui est déjà passé ne sera pas remis deux fois."
    );
    restaurer.textContent = "Restaurer dans mon coffre";
  }

  restaurer.disabled = false;
});

// --- TOUT EFFACER -----------------------------------------------
// Deux clics volontaires : on ne détruit jamais sur un seul geste.
supprimerCompte.addEventListener("click", () => {
  confirmSuppression.classList.toggle("cache");
});

confirmerSuppression.addEventListener("click", async () => {
  confirmerSuppression.disabled = true;
  confirmerSuppression.textContent = "Suppression…";

  try {
    await fetch(COFFRE + "/compte", { method: "DELETE", headers: entetes(false) });
    await chrome.storage.local.remove("kofrIdentifiant");
    await oublierSession();

    cle = null;
    jeton = null;
    compte = null;
    liste.innerHTML = "";
    identifiant.value = "";

    ecranCompte.classList.add("cache");
    ecranVerrou.classList.remove("cache");
    erreurVerrou.textContent = "Compte supprimé.";
    erreurVerrou.classList.remove("cache");
  } catch (e) {
    confirmerSuppression.textContent = "Échec — réessayez";
  }

  confirmerSuppression.disabled = false;
});

// ================================================================
// CHANGER LA PHRASE SECRÈTE
//
// Tout est déchiffré puis rechiffré ICI. Le serveur ne voit jamais
// autre chose que du chiffré, avant comme après.
// ================================================================

const nouvellePhrase  = document.getElementById("nouvellePhrase");
const nouvellePhrase2 = document.getElementById("nouvellePhrase2");
const changerPhrase   = document.getElementById("changerPhrase");
const erreurPhrase    = document.getElementById("erreurPhrase");

changerPhrase.addEventListener("click", async () => {
  erreurPhrase.classList.add("cache");

  const p1 = nouvellePhrase.value;
  const p2 = nouvellePhrase2.value;

  if (!p1 || p1.length < 8) {
    erreurPhrase.textContent = "Choisissez une phrase d'au moins 8 caractères.";
    erreurPhrase.classList.remove("cache");
    return;
  }
  if (p1 !== p2) {
    erreurPhrase.textContent = "Les deux phrases ne sont pas identiques.";
    erreurPhrase.classList.remove("cache");
    return;
  }
  if (!cle) return;

  changerPhrase.disabled = true;

  try {
    // 1. Fabriquer les nouvelles clés, avec le même sel.
    changerPhrase.textContent = "Fabrication des clés…";
    const sel = await obtenirSel(COFFRE, compte);
    const nouvelles = await fabriquerCles(p1, sel);

    // 2. Tout récupérer et tout déchiffrer avec l'ancienne clé.
    changerPhrase.textContent = "Ouverture des boîtes…";
    const reponse = await fetch(COFFRE + "/notes", { headers: entetes(false) });
    const data = await reponse.json();
    const notes = data.notes || [];

    // 3. Tout refermer avec la nouvelle.
    const refaites = [];
    for (let i = 0; i < notes.length; i++) {
      changerPhrase.textContent = "Rechiffrement… " + (i + 1) + "/" + notes.length;
      const o = await dechiffrerNote(notes[i].texte, cle);
      if (o === null) continue;              // note illisible : on ne la perd pas au hasard
      refaites.push({
        id: notes[i].id,
        texte: await chiffrerNote(o.dossier, o.texte, nouvelles.cle),
        date: notes[i].date
      });
    }

    // 4. Remplacer le contenu, puis seulement après, la serrure.
    //    Cet ordre compte : si ça casse entre les deux, l'ancienne
    //    phrase ouvre encore le coffre.
    changerPhrase.textContent = "Enregistrement…";
    await fetch(COFFRE + "/notes", {
      method: "POST",
      headers: entetes(true),
      body: JSON.stringify({ notes: refaites })
    });

    await fetch(COFFRE + "/empreinte", {
      method: "POST",
      headers: entetes(true),
      body: JSON.stringify({ jeton: nouvelles.jeton })
    });

    // 5. On adopte les nouvelles clés dans la session en cours.
    cle = nouvelles.cle;
    jeton = nouvelles.jeton;

    nouvellePhrase.value = "";
    nouvellePhrase2.value = "";
    changerPhrase.textContent = "Phrase changée";
    setTimeout(() => (changerPhrase.textContent = "Changer ma phrase"), 3000);
  } catch (e) {
    erreurPhrase.textContent = "Échec. Votre ancienne phrase fonctionne toujours.";
    erreurPhrase.classList.remove("cache");
    changerPhrase.textContent = "Changer ma phrase";
  }

  changerPhrase.disabled = false;
});

// ================================================================
// PRÉVENIR AVANT DE CRÉER UN COFFRE
//
// L'identifiant est définitif. Une faute de frappe crée un coffre
// fantôme qu'on ne retrouvera jamais. Autant le dire avant.
// ================================================================

const etatCoffre = document.getElementById("etatCoffre");

async function verifierExistence() {
  const valeur = identifiant.value.trim();
  if (!valeur) {
    etatCoffre.classList.add("cache");
    return;
  }
  try {
    const c = await identifiantCompte(valeur);
    const r = await fetch(COFFRE + "/existe", { headers: { "X-Kofr-Compte": c } });
    const d = await r.json();
    etatCoffre.textContent = d.existe
      ? "Ce coffre existe. Votre phrase va l'ouvrir."
      : "Aucun coffre à ce nom : il sera créé. Vérifiez bien l'orthographe, l'identifiant ne pourra plus être changé.";
    etatCoffre.classList.remove("cache");
  } catch (e) {
    etatCoffre.classList.add("cache");
  }
}

identifiant.addEventListener("blur", verifierExistence);

// ================================================================
// MASQUER LES NOMS
//
// On ne devine JAMAIS quels mots sont des noms propres : un logiciel
// qui devine se trompe, et se tromper ici veut dire soit laisser
// passer un nom, soit massacrer une phrase.
// C'est l'utilisateur qui décide, une fois pour toutes.
//
// La table contient de vrais noms : elle est chiffrée comme le reste.
// ================================================================

const listeNoms  = document.getElementById("listeNoms");
const nomReel    = document.getElementById("nomReel");
const nomRole    = document.getElementById("nomRole");
const ajouterNom = document.getElementById("ajouterNom");

let remplacements = [];

async function chargerRemplacements() {
  if (!cle) return;
  try {
    const r = await fetch(COFFRE + "/donnees/noms", { headers: entetes(false) });
    const d = await r.json();
    if (!d.valeur) { remplacements = []; return afficherNoms(); }
    const clair = await dechiffrer(d.valeur, cle);
    remplacements = clair ? JSON.parse(clair) : [];
  } catch (e) {
    remplacements = [];
  }
  afficherNoms();
}

async function sauverRemplacements() {
  if (!cle) return;
  const paquet = await chiffrer(JSON.stringify(remplacements), cle);
  await fetch(COFFRE + "/donnees/noms", {
    method: "POST",
    headers: entetes(true),
    body: JSON.stringify({ valeur: paquet })
  });
}

function afficherNoms() {
  listeNoms.innerHTML = "";
  remplacements.forEach((p, index) => {
    const li = document.createElement("li");

    const reel = document.createElement("span");
    reel.className = "reel";
    reel.textContent = p.reel;

    const fleche = document.createElement("span");
    fleche.className = "fleche";
    fleche.textContent = "→";

    const role = document.createElement("span");
    role.className = "role";
    role.textContent = p.role;

    const croix = document.createElement("button");
    croix.className = "supprimer";
    croix.textContent = "×";
    croix.addEventListener("click", async () => {
      remplacements.splice(index, 1);
      await sauverRemplacements();
      afficherNoms();
    });

    li.appendChild(reel);
    li.appendChild(fleche);
    li.appendChild(role);
    li.appendChild(croix);
    listeNoms.appendChild(li);
  });
}

ajouterNom.addEventListener("click", async () => {
  const r = nomReel.value.trim();
  const ro = nomRole.value.trim();
  if (!r || !ro) return;

  ajouterNom.disabled = true;
  remplacements.push({ reel: r, role: ro });
  await sauverRemplacements();
  nomReel.value = "";
  nomRole.value = "";
  afficherNoms();
  ajouterNom.disabled = false;
});

nomRole.addEventListener("keydown", (e) => {
  if (e.key === "Enter") ajouterNom.click();
});

// --- L'APPLICATION, AU MOMENT DE L'ENVOI ------------------------
// Insensible à la casse, et on protège les caractères spéciaux
// pour qu'un nom comme « Saint-Ex » ne casse pas la recherche.
function echapper(texte) {
  return texte.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function masquerNoms(texte) {
  let sortie = texte;
  remplacements.forEach((p) => {
    if (!p.reel) return;
    sortie = sortie.replace(new RegExp(echapper(p.reel), "gi"), p.role);
  });
  return sortie;
}

// ================================================================
// MASQUAGE AUTOMATIQUE
//
// Kofr repère les noms, propose un remplacement, et retient.
// Après deux ou trois envois, plus rien n'est demandé.
// ================================================================

const masquageActif = document.getElementById("masquageActif");
const ecranNoms     = document.getElementById("ecranNoms");
const nomsReperes   = document.getElementById("nomsReperes");
const validerNoms   = document.getElementById("validerNoms");
const annulerNoms   = document.getElementById("annulerNoms");

// Ce qu'on fera une fois les noms validés.
let apresValidation = null;

masquageActif.addEventListener("change", async () => {
  await chrome.storage.local.set({ kofrMasquage: masquageActif.checked });
});

async function chargerReglageMasquage() {
  const d = await chrome.storage.local.get("kofrMasquage");
  masquageActif.checked = d.kofrMasquage !== false;   // activé par défaut
}

// --- LE PASSAGE OBLIGÉ ------------------------------------------
// Tout ce qui part vers une IA traverse cette fonction.
// Si des noms inconnus apparaissent, on s'arrête et on demande.
async function preparerEnvoi(texte, suite) {
  if (!masquageActif.checked) return suite(texte);

  const nouveaux = nouveauxNoms(texte, remplacements);
  if (!nouveaux.length) return suite(masquerNoms(texte));

  // On montre, puis on enverra.
  apresValidation = { texte: texte, suite: suite };

  // Le bouton annonce l'action réelle : envoyer, ou copier.
  validerNoms.textContent = (suite === envoyerVraiment)
    ? "Envoyer"
    : "Copier";

  nomsReperes.innerHTML = "";
  nouveaux.forEach((nom) => {
    const li = document.createElement("li");

    const tete = document.createElement("div");
    tete.className = "tete";

    const coche = document.createElement("input");
    coche.type = "checkbox";
    coche.checked = true;

    const gras = document.createElement("b");
    gras.textContent = nom;

    const devient = document.createElement("span");
    devient.className = "devient";
    devient.textContent = "sera remplacé par";

    tete.appendChild(coche);
    tete.appendChild(gras);
    tete.appendChild(devient);

    const champ = document.createElement("input");
    champ.type = "text";
    champ.value = proposerRole(nom, texte);

    li.dataset.nom = nom;
    li.appendChild(tete);
    li.appendChild(champ);
    nomsReperes.appendChild(li);
  });

  ecranCoffre.classList.add("cache");
  ecranPreparer.classList.add("cache");
  ecranNoms.classList.remove("cache");
}

validerNoms.addEventListener("click", async () => {
  validerNoms.disabled = true;

  // On retient TOUT, y compris les mots écartés : ils sont
  // enregistrés comme « ne rien changer », pour ne plus jamais
  // reposer la question.
  nomsReperes.querySelectorAll("li").forEach((li) => {
    const nom = li.dataset.nom;
    const coche = li.querySelector('input[type=checkbox]').checked;
    const role = li.querySelector('input[type=text]').value.trim();
    remplacements.push({ reel: nom, role: coche && role ? role : nom });
  });

  await sauverRemplacements();
  afficherNoms();

  ecranNoms.classList.add("cache");
  validerNoms.disabled = false;

  if (apresValidation) {
    const { texte, suite } = apresValidation;
    apresValidation = null;
    await suite(masquerNoms(texte));
  }
});

annulerNoms.addEventListener("click", () => {
  apresValidation = null;
  ecranNoms.classList.add("cache");
  (ecranRetourEnvoi || ecranPreparer).classList.remove("cache");
});

// ================================================================
// CONVERSATIONS SANS TRACE
//
// ChatGPT accepte un paramètre d'adresse qui ouvre directement une
// conversation temporaire : pas d'historique, pas de mémoire, pas
// d'entraînement. La mémoire vit dans le coffre, plus chez eux.
// ================================================================

const modeTemporaire = document.getElementById("modeTemporaire");
const choixIA = document.getElementById("choixIA");
const avertTemporaire = document.getElementById("avertTemporaire");

// L'IA que Kofr ouvre quand aucune n'est déjà ouverte.
let iaChoisie = "chatgpt";

function remplirChoixIA() {
  choixIA.innerHTML = "";
  SITES_IA.forEach((site) => {
    const o = document.createElement("option");
    o.value = site.cle;
    o.textContent = site.nom;
    choixIA.appendChild(o);
  });
  choixIA.value = iaChoisie;
}

async function chargerChoixIA() {
  try {
    const d = await chrome.storage.local.get("kofrIA");
    if (d.kofrIA && siteParCle(d.kofrIA).cle === d.kofrIA) iaChoisie = d.kofrIA;
  } catch (e) {}
  remplirChoixIA();
  majAvertTemporaire();
}

choixIA.addEventListener("change", async () => {
  iaChoisie = choixIA.value;
  try { await chrome.storage.local.set({ kofrIA: iaChoisie }); } catch (e) {}
  majAvertTemporaire();
});

// On ne promet pas ce qu'on ne peut pas tenir : seul ChatGPT ouvre
// une conversation temporaire par son adresse.
function majAvertTemporaire() {
  const site = siteParCle(iaChoisie);
  if (modeTemporaire.checked && !site.temporaire) {
    avertTemporaire.textContent =
      site.nom + " n'a pas d'adresse pour ouvrir une conversation temporaire. " +
      "Activez-la vous-même dans " + site.nom +
      " — Kofr ne peut pas le faire à votre place.";
    avertTemporaire.classList.remove("cache");
  } else {
    avertTemporaire.classList.add("cache");
  }
}

const bandeauTemporaire = document.getElementById("bandeauTemporaire");

function montrerTemoinTemporaire() {
  bandeauTemporaire.classList.toggle("cache", !modeTemporaire.checked);
}

modeTemporaire.addEventListener("change", async () => {
  await chrome.storage.local.set({ kofrTemporaire: modeTemporaire.checked });
  montrerTemoinTemporaire();
  majAvertTemporaire();
});

async function chargerReglageTemporaire() {
  const d = await chrome.storage.local.get("kofrTemporaire");
  modeTemporaire.checked = d.kofrTemporaire === true;   // éteint par défaut
  montrerTemoinTemporaire();
  majAvertTemporaire();
}

function adresseAOuvrir() {
  const site = siteParCle(iaChoisie);
  return (modeTemporaire.checked && site.temporaire)
    ? site.temporaire
    : site.accueil;
}

// Quel onglet ChatGPT peut recevoir notre texte ?
//
// En mode normal : n'importe lequel.
//
// En mode SANS TRACE : surtout pas n'importe lequel. Réutiliser une
// conversation ordinaire, c'est écrire dans l'historique et nourrir
// la mémoire de ChatGPT — exactement ce qu'on veut éviter. On ne
// réutilise donc qu'une conversation déjà temporaire ; sinon on en
// ouvre une neuve. C'est le bug que Celyan a repéré : l'option
// était cochée mais ne servait à rien tant qu'un onglet traînait.
async function ongletPourEcrire() {
  const onglets = await chrome.tabs.query({ url: TOUS_MOTIFS });
  if (!onglets.length) return null;
  if (!modeTemporaire.checked) return onglets[0];

  // L'adresse porte encore la marque du mode temporaire…
  const marque = onglets.find(
    (o) => (o.url || "").indexOf("temporary-chat=true") !== -1
  );
  if (marque) return marque;

  // …ou bien c'est celui que nous avions ouvert nous-mêmes.
  try {
    const d = await chrome.storage.local.get("kofrOngletTemporaire");
    const garde = onglets.find((o) => o.id === d.kofrOngletTemporaire);
    if (garde) return garde;
  } catch (e) {}

  return null;
}

// On se souvient de l'onglet temporaire qu'on vient d'ouvrir :
// son adresse changera dès le premier message.
async function retenirOngletTemporaire(onglet) {
  if (!modeTemporaire.checked || !onglet) return;
  try {
    await chrome.storage.local.set({ kofrOngletTemporaire: onglet.id });
  } catch (e) {}
}

// ================================================================
// RESTER DÉVERROUILLÉ
//
// La clé vit en mémoire du navigateur, jamais sur le disque, et
// disparaît quand on ferme le navigateur ou qu'on verrouille.
// C'est ce que font les gestionnaires de mots de passe : sans ça,
// personne ne retape une phrase secrète dix fois par jour.
// ================================================================

async function memoriserSession() {
  try {
    await chrome.storage.session.set({
      kofrSession: { cle: cle, jeton: jeton, compte: compte }
    });
  } catch (e) {
    // Si le navigateur refuse de garder la clé, tant pis :
    // l'utilisateur retapera sa phrase. On ne dégrade rien.
  }
}

async function oublierSession() {
  try { await chrome.storage.session.remove("kofrSession"); } catch (e) {}
}

async function reprendreSession() {
  try {
    const d = await chrome.storage.session.get("kofrSession");
    const s = d.kofrSession;
    if (!s || !s.cle || !s.jeton || !s.compte) return false;

    cle = s.cle;
    jeton = s.jeton;
    compte = s.compte;

    // On vérifie que la clé est encore utilisable avant d'ouvrir.
    await chiffrer("test", cle);
    return true;
  } catch (e) {
    await oublierSession();
    return false;
  }
}

// ================================================================
// DOSSIERS
//
// Le nom du dossier peut être aussi révélateur que la note
// elle-même — « divorce », « recherche d'emploi ». Il est donc
// rangé À L'INTÉRIEUR du contenu chiffré : le serveur ne sait
// même pas combien vous avez de dossiers.
//
// Format d'une note : {"d":"dossier","t":"texte"}, chiffré.
// Les anciennes notes, du texte brut, restent lisibles.
// ================================================================


// --- LE RAPPEL DE COPIE -----------------------------------------
//
// On vient de construire la restauration. Elle ne sert à rien si
// personne ne télécharge jamais de copie. Et le jour où quelqu'un
// oublie sa phrase, il est trop tard pour y penser.
//
// Alors on le dit, une fois que le coffre a assez de contenu pour
// que sa perte fasse mal. Discrètement, et sans insister.

const rappelCopie  = document.getElementById("rappelCopie");
const rappelTexte  = document.getElementById("rappelTexte");
const allerExport  = document.getElementById("allerExport");

const SEUIL_RAPPEL = 8;          // en dessous, la perte est indolore
const AGE_COPIE    = 30;         // jours avant qu'une copie soit périmée

async function verifierCopie() {
  rappelCopie.classList.add("cache");
  if (toutesNotes.length < SEUIL_RAPPEL) return;

  let derniere = null;
  try {
    const d = await chrome.storage.local.get("kofrDernierExport");
    derniere = (d.kofrDernierExport || {})[compte] || null;
  } catch (e) {}

  let jours = null;
  if (derniere) {
    const q = new Date(derniere);
    if (!isNaN(q.getTime())) {
      jours = Math.floor((Date.now() - q.getTime()) / 86400000);
    }
  }

  if (jours !== null && jours < AGE_COPIE) return;

  rappelTexte.textContent = jours === null
    ? "Vous avez " + toutesNotes.length + " informations dans votre coffre et " +
      "aucune copie. Si vous perdiez votre phrase secrète, tout disparaîtrait " +
      "— personne ne peut la retrouver, nous compris."
    : "Votre dernière copie date de " + jours + " jours. Depuis, votre coffre " +
      "a change.";

  rappelCopie.classList.remove("cache");
}

allerExport.addEventListener("click", () => {
  ecranCoffre.classList.add("cache");
  ecranCompte.classList.remove("cache");
  exporter.scrollIntoView({ block: "center" });
});

async function noterCopie() {
  try {
    const d = await chrome.storage.local.get("kofrDernierExport");
    const tout = d.kofrDernierExport || {};
    tout[compte] = new Date().toISOString();
    await chrome.storage.local.set({ kofrDernierExport: tout });
  } catch (e) {}
}

const dossierImport = document.getElementById("dossierImport");
const listeDossiers = document.getElementById("listeDossiers");
const filtreDossier = document.getElementById("filtreDossier");

const vueProjets      = document.getElementById("vueProjets");
const vueProjet       = document.getElementById("vueProjet");
const listeProjets    = document.getElementById("listeProjets");
const videProjets     = document.getElementById("videProjets");
const titreProjet     = document.getElementById("titreProjet");
const sousTitreProjet = document.getElementById("sousTitreProjet");
const titreHistorique = document.getElementById("titreHistorique");
const retourProjets   = document.getElementById("retourProjets");
const nouveauProjet   = document.getElementById("nouveauProjet");
const formProjet      = document.getElementById("formProjet");
const nomNouveau      = document.getElementById("nomNouveau");
const creerProjet     = document.getElementById("creerProjet");
const reprendreProjet = document.getElementById("reprendreProjet");
const sauverIci       = document.getElementById("sauverIci");
const envoyerDepuisProjet = document.getElementById("envoyerDepuisProjet");
const renommerChamp   = document.getElementById("renommerChamp");
const renommerProjet  = document.getElementById("renommerProjet");
const supprimerProjet = document.getElementById("supprimerProjet");

// null = on regarde la liste ; "" = le projet « Sans projet » ; sinon son nom.
let projetOuvert = null;
let toutesNotes  = [];
let projetsVides = [];       // créés mais encore vides — mémoire locale

// L'envoi vers une IA peut partir de plusieurs écrans. On note d'où.
let ecranRetourEnvoi = null;
let boutonEnvoi = null;
let libelleEnvoi = "";

function viserEnvoi(ecran, bouton, libelle) {
  ecranRetourEnvoi = ecran;
  boutonEnvoi = bouton;
  libelleEnvoi = libelle;
}

// --- LE FORMAT D'UNE NOTE ---------------------------------------
// {"d":"projet","t":"texte","j":"2026-08-21T..."} — le tout chiffré.
// Les anciennes notes, en texte brut, restent lisibles.
async function chiffrerNote(dossier, texte, uneCle) {
  return chiffrer(JSON.stringify({
    d: dossier || "",
    t: texte,
    j: new Date().toISOString()
  }), uneCle);
}

async function dechiffrerNote(paquet, uneCle) {
  const clair = await dechiffrer(paquet, uneCle);
  if (clair === null) return null;
  try {
    const o = JSON.parse(clair);
    if (o && typeof o.t === "string")
      return { dossier: o.d || "", texte: o.t, date: o.j || "" };
  } catch (e) {}
  return { dossier: "", texte: clair, date: "" };
}

// --- LES DATES, EN FRANÇAIS -------------------------------------
function jourLisible(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  return d.toLocaleDateString("fr-FR",
    { day: "numeric", month: "long", year: "numeric" });
}

function depuisQuand(iso) {
  if (!iso) return "sans date";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "sans date";
  const jours = Math.floor((Date.now() - d.getTime()) / 86400000);
  if (jours <= 0) return "aujourd'hui";
  if (jours === 1) return "hier";
  if (jours < 31) return "il y a " + jours + " jours";
  if (jours < 365) return "il y a " + Math.floor(jours / 30) + " mois";
  return "il y a plus d'un an";
}

function derniereDate(lot) {
  for (let i = lot.length - 1; i >= 0; i--) if (lot[i].date) return lot[i].date;
  return "";
}

// --- LES PROJETS VIDES ------------------------------------------
// Un projet qu'on vient de créer n'a encore aucune note : le serveur
// ne peut pas le connaître (il ne voit que du chiffré). On s'en
// souvient donc ici, sur cet ordinateur, jusqu'à sa première note.
async function chargerProjetsVides() {
  try {
    const data = await chrome.storage.local.get("kofrProjetsVides");
    projetsVides = (data.kofrProjetsVides || {})[compte] || [];
  } catch (e) { projetsVides = []; }
}

async function sauverProjetsVides() {
  try {
    const data = await chrome.storage.local.get("kofrProjetsVides");
    const tout = data.kofrProjetsVides || {};
    tout[compte] = projetsVides;
    await chrome.storage.local.set({ kofrProjetsVides: tout });
  } catch (e) {}
}

// --- LA LISTE DES PROJETS ---------------------------------------
function afficherProjets() {
  projetOuvert = null;
  vueProjet.classList.add("cache");
  vueProjets.classList.remove("cache");

  const groupes = new Map();
  toutesNotes.forEach((n) => {
    const nom = n.dossier || "";
    if (!groupes.has(nom)) groupes.set(nom, []);
    groupes.get(nom).push(n);
  });
  projetsVides.forEach((nom) => { if (!groupes.has(nom)) groupes.set(nom, []); });

  // Le plus récemment touché en haut ; « Sans projet » toujours en bas.
  const noms = Array.from(groupes.keys()).sort((a, b) => {
    if (a === "") return 1;
    if (b === "") return -1;
    const da = derniereDate(groupes.get(a));
    const db = derniereDate(groupes.get(b));
    if (da === db) return a.localeCompare(b);
    return db > da ? 1 : -1;
  });

  listeProjets.innerHTML = "";

  noms.forEach((nom) => {
    const lot = groupes.get(nom);
    const li = document.createElement("li");

    const b = document.createElement("button");
    b.className = "projet";

    const titre = document.createElement("span");
    titre.className = "nom";
    titre.textContent = nom || "Sans projet";
    b.appendChild(titre);

    const meta = document.createElement("span");
    meta.className = "meta";
    meta.textContent = lot.length
      ? lot.length + " information" + (lot.length > 1 ? "s" : "") +
        " · " + depuisQuand(derniereDate(lot))
      : "vide pour l'instant";
    b.appendChild(meta);

    const dernier = lot.length ? lot[lot.length - 1] : null;
    if (dernier && dernier.texte) {
      const extrait = document.createElement("span");
      extrait.className = "extrait";
      extrait.textContent = dernier.texte;
      b.appendChild(extrait);
    }

    b.addEventListener("click", () => ouvrirProjet(nom));
    li.appendChild(b);
    listeProjets.appendChild(li);
  });

  verifierCopie();

  if (noms.length) {
    videProjets.style.display = "none";
  } else {
    videProjets.textContent =
      "Votre coffre est encore vide. Créez un projet, " +
      "ou remplissez-le depuis ChatGPT.";
    videProjets.style.display = "block";
  }
}

// --- DANS UN PROJET ---------------------------------------------
function ouvrirProjet(nom) {
  projetOuvert = nom;
  formProjet.classList.add("cache");
  vueProjets.classList.add("cache");
  vueProjet.classList.remove("cache");
  afficherHistorique();
}

function afficherHistorique() {
  const lot = toutesNotes.filter((n) => (n.dossier || "") === projetOuvert);

  titreProjet.textContent = projetOuvert || "Sans projet";
  sousTitreProjet.textContent = projetOuvert
    ? "Son histoire, du plus ancien au plus récent."
    : "Ce qui n'est rattaché à aucun projet.";

  liste.innerHTML = "";
  lot.forEach((n) => liste.appendChild(fabriquerLigne(n)));

  titreHistorique.textContent = lot.length
    ? lot.length + " information" + (lot.length > 1 ? "s" : "")
    : "Historique";

  if (lot.length) {
    vide.style.display = "none";
  } else {
    vide.textContent =
      "Rien ici pour l'instant. Écrivez ci-dessous, " +
      "ou sauvez une conversation dans ce projet.";
    vide.style.display = "block";
  }

  reprendreProjet.disabled = !lot.length;
  renommerChamp.value = projetOuvert || "";

  // « Sans projet » n'est pas un vrai projet : ni renommage ni suppression.
  const vrai = !!projetOuvert;
  renommerChamp.disabled = !vrai;
  renommerProjet.disabled = !vrai;
  supprimerProjet.disabled = !vrai;
}

retourProjets.addEventListener("click", () => afficherProjets());

// --- CRÉER UN PROJET --------------------------------------------
nouveauProjet.addEventListener("click", () => {
  formProjet.classList.toggle("cache");
  if (!formProjet.classList.contains("cache")) nomNouveau.focus();
});

creerProjet.addEventListener("click", async () => {
  const nom = nomNouveau.value.trim();
  if (!nom) return;
  if (!projetsVides.includes(nom)) {
    projetsVides.push(nom);
    await sauverProjetsVides();
  }
  nomNouveau.value = "";
  ouvrirProjet(nom);
});

nomNouveau.addEventListener("keydown", (e) => {
  if (e.key === "Enter") creerProjet.click();
});

// --- REPRENDRE CE PROJET ----------------------------------------
// Le cœur du produit : l'IA ne retient rien, c'est nous qui lui
// rendons le fil, dans l'ordre, à chaque fois.
reprendreProjet.addEventListener("click", async () => {
  const lot = toutesNotes.filter(
    (n) => (n.dossier || "") === projetOuvert && n.texte
  );
  if (!lot.length) return;

  const lignes = lot.map((n, i) => {
    const quand = n.date ? "[" + jourLisible(n.date) + "] " : "";
    return (i + 1) + ". " + quand + n.texte;
  });

  const bloc =
    "Nous reprenons un travail en cours" +
    (projetOuvert ? " : " + projetOuvert : "") + ".\n" +
    "Voici tout l'historique, du plus ancien au plus récent. Lis-le, puis " +
    "dis-moi en trois lignes maximum où nous en sommes et quelle est la " +
    "prochaine étape. N'invente rien qui ne figure pas ci-dessous.\n\n" +
    lignes.join("\n");

  viserEnvoi(ecranCoffre, reprendreProjet, "Reprendre ce projet");
  await preparerEnvoi(bloc, envoyerVraiment);
});

// --- LES DEUX RACCOURCIS DU PROJET ------------------------------
sauverIci.addEventListener("click", () => {
  destinationRecuperation = projetOuvert || "";
  recupererConv.click();
  sauverIci.textContent = "Appuyez sur Entrée dans l’IA";
  setTimeout(() => {
    sauverIci.innerHTML = "Sauver la conversation<br><small>dans ce projet</small>";
  }, 4000);
});

envoyerDepuisProjet.addEventListener("click", () => {
  ecranCoffre.classList.add("cache");
  ecranPreparer.classList.remove("cache");
  filtreDossier.value = projetOuvert || "";
  sujet.focus();
});

// --- RENOMMER -----------------------------------------------------
// Le serveur ne sait pas ce qu'est un projet : le nom est à
// l'intérieur du chiffré. On rechiffre donc chaque note, ici.
renommerProjet.addEventListener("click", async () => {
  const neuf = renommerChamp.value.trim();
  if (!neuf || neuf === projetOuvert || !cle) return;

  const lot = toutesNotes.filter(
    (n) => (n.dossier || "") === projetOuvert && n.texte !== null
  );

  renommerProjet.disabled = true;
  for (let i = 0; i < lot.length; i++) {
    renommerProjet.textContent = "Renommage… " + (i + 1) + "/" + lot.length;
    const paquet = await chiffrer(JSON.stringify({
      d: neuf, t: lot[i].texte, j: lot[i].date || new Date().toISOString()
    }), cle);
    await fetch(COFFRE + "/note", {
      method: "POST", headers: entetes(true),
      body: JSON.stringify({ texte: paquet })
    });
    await fetch(COFFRE + "/note/" + lot[i].id,
      { method: "DELETE", headers: entetes(false) });
  }

  projetsVides = projetsVides.filter((p) => p !== projetOuvert);
  if (!lot.length && !projetsVides.includes(neuf)) projetsVides.push(neuf);
  await sauverProjetsVides();

  renommerProjet.disabled = false;
  renommerProjet.textContent = "Renommer";
  projetOuvert = neuf;
  await charger();
});

// --- SUPPRIMER ----------------------------------------------------
let suppressionArmee = false;
supprimerProjet.addEventListener("click", async () => {
  if (!suppressionArmee) {
    suppressionArmee = true;
    supprimerProjet.textContent = "Confirmer : tout effacer";
    setTimeout(() => {
      suppressionArmee = false;
      supprimerProjet.textContent = "Supprimer ce projet";
    }, 5000);
    return;
  }
  suppressionArmee = false;

  const lot = toutesNotes.filter((n) => (n.dossier || "") === projetOuvert);
  supprimerProjet.disabled = true;
  for (let i = 0; i < lot.length; i++) {
    supprimerProjet.textContent = "Suppression… " + (i + 1) + "/" + lot.length;
    if (lot[i].id) {
      await fetch(COFFRE + "/note/" + lot[i].id,
        { method: "DELETE", headers: entetes(false) });
    }
  }

  projetsVides = projetsVides.filter((p) => p !== projetOuvert);
  await sauverProjetsVides();

  supprimerProjet.disabled = false;
  supprimerProjet.textContent = "Supprimer ce projet";
  projetOuvert = null;
  await charger();
});

// --- LES SUGGESTIONS DE NOMS ------------------------------------
function majListeDossiers() {
  const noms = new Set(projetsVides);
  toutesNotes.forEach((n) => { if (n.dossier) noms.add(n.dossier); });
  const tries = Array.from(noms).sort();

  listeDossiers.innerHTML = "";
  tries.forEach((nom) => {
    const o = document.createElement("option");
    o.value = nom;
    listeDossiers.appendChild(o);
  });

  const choisi = filtreDossier.value;
  filtreDossier.innerHTML = '<option value="">Tous les projets</option>';
  tries.forEach((nom) => {
    const o = document.createElement("option");
    o.value = nom;
    o.textContent = nom;
    filtreDossier.appendChild(o);
  });
  filtreDossier.value = choisi;
}
