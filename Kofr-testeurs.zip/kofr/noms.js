// ---------------------------------------------------------------
// Kofr — noms.js
//
// Repère les noms propres pour proposer de les masquer.
//
// PRINCIPE : puisque l'utilisateur valide, on préfère SUR-détecter.
// Un mot proposé à tort se décoche en une seconde ; un nom raté
// part pour toujours. Les deux erreurs n'ont pas le même prix.
//
// On attrape donc trois familles :
//   - les mots capitalisés en milieu de phrase
//   - les mots qui suivent « chez », « avec », « à »…
//   - les prénoms courants, même en minuscules
// moins les mots français ordinaires.
// ---------------------------------------------------------------

// Le vocabulaire courant : ce qui n'est jamais un nom propre.
const MOTS_COURANTS = new Set(("" +
"je tu il elle on nous vous ils elles me te se lui leur moi toi soi " +
"le la les un une des du de au aux ce cet cette ces mon ma mes ton ta tes " +
"son sa ses notre nos votre vos leurs " +
"et ou mais donc or ni car si que qui quoi dont ou quand comme " +
"pour par avec sans sous sur dans chez vers depuis pendant avant apres " +
"entre contre selon malgre pres loin ici la bas haut " +
"etre avoir faire dire aller voir savoir pouvoir vouloir devoir falloir " +
"venir prendre mettre passer donner trouver parler aimer travailler " +
"suis es est sommes etes sont ai as avons avez ont " +
"fais fait faisons faites font vais vas va allons allez vont " +
"travail travaille boulot metier projet client dossier reunion equipe " +
"maison appartement bureau ville rue famille ami amie amis " +
"jour jours semaine mois annee annees heure heures matin soir nuit " +
"lundi mardi mercredi jeudi vendredi samedi dimanche " +
"janvier fevrier mars avril mai juin juillet aout septembre octobre novembre decembre " +
"oui non merci bonjour salut voici voila alors ensuite enfin aussi " +
"tout tous toute toutes plus moins tres bien mal peu beaucoup trop assez " +
"grand grande petit petite bon bonne nouveau nouvelle premier derniere " +
"euro euros heure prix budget cout argent " +
"internet ordinateur telephone mail email site page fichier " +
"aujourd hui hier demain maintenant toujours jamais souvent parfois " +
"cependant toutefois pourtant ainsi donc puis apres avant " +
"chose choses truc machin quelque quelques chaque plusieurs autre autres"
).split(/\s+/));

// Les outils et marques qu'on ne masque pas.
const CONNUS = new Set(("" +
"excel word powerpoint outlook google chatgpt claude gemini mistral kofr " +
"windows mac linux chrome edge firefox safari youtube linkedin instagram " +
"facebook whatsapp tiktok netflix spotify amazon apple microsoft openai " +
"france francais francaise europe euro bts cdi cdd tva pdf ia rgpd sarl sas"
).split(/\s+/));

// Après ces mots, ce qui suit est très souvent un nom propre.
const MARQUEURS_NOMS = new Set(("" +
"chez avec pour de du a au monsieur madame mr mme docteur maitre " +
"appelle nomme habite travaille rencontre vu voir contacte"
).split(/\s+/));

// Prénoms fréquents, pour les attraper même sans majuscule.
const PRENOMS = new Set(("" +
"jean pierre michel andre philippe rene louis alain jacques bernard marcel " +
"daniel roger robert paul claude christian thierry eric patrick nicolas " +
"laurent stephane pascal frederic david olivier sebastien julien vincent " +
"antoine maxime alexandre thomas nathan lucas hugo enzo mathis noah " +
"tom leo gabriel raphael arthur jules adam liam ethan sacha " +
"marie nathalie isabelle sylvie catherine martine christine francoise " +
"monique nicole sandrine stephanie veronique valerie caroline julie " +
"sophie celine laurence emilie aurelie camille laura marine manon " +
"chloe emma lea sarah lucie clara jade louise alice lina ambre rose " +
"celyan louis giverdon"
).split(/\s+/));

function sansAccents(t) {
  return t.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
}

function nettoyer(mot) {
  return mot.replace(/^[^\wÀ-ÿ]+/, "").replace(/[^\wÀ-ÿ'-]+$/, "");
}

// --- REPÉRER -----------------------------------------------------
function reperer(texte) {
  const trouves = new Map();
  const phrases = texte.split(/(?<=[.!?:\n])\s+/);

  phrases.forEach(function (phrase) {
    const mots = phrase.split(/\s+/);

    mots.forEach(function (motBrut, index) {
      const mot = nettoyer(motBrut);
      if (mot.length < 3) return;

      const simple = sansAccents(mot);

      // Jamais un nom propre.
      if (MOTS_COURANTS.has(simple)) return;
      if (CONNUS.has(simple)) return;
      if (/^\d+$/.test(simple)) return;

      // Sigles courts tout en majuscules.
      if (mot === mot.toUpperCase() && mot.length <= 4) return;

      let candidat = false;

      // 1. Capitalisé ailleurs qu'en début de phrase.
      const capitalise =
        mot[0] === mot[0].toUpperCase() && mot[0] !== mot[0].toLowerCase();
      if (capitalise && index > 0) candidat = true;

      // 2. Précédé d'un marqueur : « chez giverdon », « avec tom ».
      if (index > 0) {
        const precedent = sansAccents(nettoyer(mots[index - 1]));
        if (MARQUEURS_NOMS.has(precedent)) candidat = true;
      }

      // 3. Prénom connu, même en minuscules.
      if (PRENOMS.has(simple)) candidat = true;

      if (!candidat) return;

      if (!trouves.has(simple)) trouves.set(simple, mot);
    });
  });

  return Array.from(trouves.values());
}

// --- PROPOSER UN REMPLACEMENT ------------------------------------
function proposerRole(nom, texte) {
  const echappe = nom.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  if (new RegExp("chez\\s+" + echappe, "i").test(texte)) return "mon employeur";
  if (new RegExp("(a|de|vers)\\s+" + echappe, "i").test(texte)) return "ma ville";
  if (PRENOMS.has(sansAccents(nom))) return "une personne";
  return "une personne";
}

// --- CE QUI RESTE À DEMANDER -------------------------------------
function nouveauxNoms(texte, connus) {
  const dejaVus = new Set((connus || []).map(function (p) {
    return sansAccents(p.reel);
  }));
  return reperer(texte).filter(function (n) {
    return !dejaVus.has(sansAccents(n));
  });
}
