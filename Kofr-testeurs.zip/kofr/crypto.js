// ---------------------------------------------------------------
// Kofr — crypto.js
// Tout ce qui touche au chiffrement vit ici, et rien d'autre.
//
// RÈGLE D'OR : on n'invente aucun algorithme. On utilise WebCrypto,
// la bibliothèque de sécurité intégrée au navigateur.
// ---------------------------------------------------------------

// --- LE SEL -----------------------------------------------------
// Un grain de sable unique à ton coffre. Il fait que ta clé sera
// différente de celle d'une autre personne ayant la même phrase.
//
// Il n'est PAS secret : il peut être stocké en clair sur le serveur.
// Et il DOIT y être, sinon changer d'ordinateur ferait perdre le coffre.
async function obtenirSel(adresseCoffre, compte) {
  // 1. Le serveur en a-t-il déjà un pour CE coffre ?
  const reponse = await fetch(adresseCoffre + "/sel", {
    headers: { "X-Kofr-Compte": compte }
  });
  const data = await reponse.json();
  if (data.sel) return depuisBase64(data.sel);

  // 2. Première utilisation : on en fabrique un et on le dépose.
  const nouveau = crypto.getRandomValues(new Uint8Array(16));
  const envoi = await fetch(adresseCoffre + "/sel", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Kofr-Compte": compte },
    body: JSON.stringify({ sel: versBase64(nouveau) })
  });
  const confirme = await envoi.json();
  return depuisBase64(confirme.sel);
}

// --- FABRIQUER LES CLÉS -----------------------------------------
// Une seule phrase, DEUX clés :
//   - la clé de chiffrement : ferme les boîtes, ne sort jamais d'ici
//   - le jeton : prouve au serveur que c'est bien toi
// Elles sortent du même calcul mais sont indépendantes : connaître
// l'une ne permet pas de retrouver l'autre.
async function fabriquerCles(phrase, sel) {
  const base = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(phrase),
    "PBKDF2",
    false,
    ["deriveBits"]
  );

  // 600 000 répétitions : une seconde pour toi, des années pour un attaquant.
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: sel, iterations: 600000, hash: "SHA-256" },
    base,
    512
  );
  const octets = new Uint8Array(bits);

  const cle = await crypto.subtle.importKey(
    "raw",
    octets.slice(0, 32),
    { name: "AES-GCM" },
    false,
    ["encrypt", "decrypt"]
  );

  return { cle: cle, jeton: versBase64(octets.slice(32, 64)) };
}

// --- FERMER LA BOÎTE --------------------------------------------
// L'IV est un numéro aléatoire tiré à chaque fois. Il garantit que
// deux fois le même texte ne donnent jamais le même résultat.
async function chiffrer(texte, cle) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const chiffre = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv },
    cle,
    new TextEncoder().encode(texte)
  );
  return versBase64(iv) + "." + versBase64(new Uint8Array(chiffre));
}

// --- OUVRIR LA BOÎTE --------------------------------------------
// Renvoie null si la clé est mauvaise. Pas de message d'erreur
// détaillé : on ne renseigne jamais un attaquant.
async function dechiffrer(paquet, cle) {
  try {
    const morceaux = paquet.split(".");
    const clair = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: depuisBase64(morceaux[0]) },
      cle,
      depuisBase64(morceaux[1])
    );
    return new TextDecoder().decode(clair);
  } catch (e) {
    return null;
  }
}

// --- Utilitaires ------------------------------------------------
function versBase64(octets) {
  let binaire = "";
  for (let i = 0; i < octets.length; i++) binaire += String.fromCharCode(octets[i]);
  return btoa(binaire);
}

function depuisBase64(texte) {
  return Uint8Array.from(atob(texte), function (c) { return c.charCodeAt(0); });
}

// --- L'IDENTIFIANT DU COFFRE ------------------------------------
// Public, comme une adresse e-mail : il dit QUEL coffre ouvrir,
// jamais s'il vous appartient. C'est la phrase qui le prouve.
// On le transforme en empreinte pour éviter les caractères
// exotiques dans les étiquettes du serveur.
async function identifiantCompte(texte) {
  const propre = texte.trim().toLowerCase();
  const hash = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(propre)
  );
  return Array.from(new Uint8Array(hash))
    .map(function (o) { return o.toString(16).padStart(2, "0"); })
    .join("")
    .slice(0, 32);
}
