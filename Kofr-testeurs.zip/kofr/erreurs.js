// ---------------------------------------------------------------
// Kofr — erreurs.js
//
// Affiche les erreurs directement dans la fenêtre, en rouge.
// Une extension ne laisse pas voir sa console facilement : sans
// ça, on répare à l'aveugle.
// ---------------------------------------------------------------

(function () {
  function montrer(titre, detail) {
    let bandeau = document.getElementById("kofrErreur");
    if (!bandeau) {
      bandeau = document.createElement("div");
      bandeau.id = "kofrErreur";
      bandeau.style.cssText =
        "position:fixed;top:0;left:0;right:0;max-height:45%;overflow:auto;" +
        "background:#A8443A;color:#fff;padding:10px 12px;font-size:11px;" +
        "line-height:1.45;z-index:99999;white-space:pre-wrap;" +
        "font-family:monospace;cursor:pointer;";
      bandeau.title = "Cliquer pour masquer";
      bandeau.addEventListener("click", function () { bandeau.remove(); });
      (document.body || document.documentElement).appendChild(bandeau);
    }
    bandeau.textContent += titre + "\n" + detail + "\n\n";
  }

  window.addEventListener("error", function (e) {
    montrer("ERREUR : " + e.message,
            (e.filename || "").split("/").pop() + " ligne " + e.lineno);
  });

  window.addEventListener("unhandledrejection", function (e) {
    const r = e.reason;
    montrer("PROMESSE REJETÉE : " + (r && r.message ? r.message : String(r)),
            (r && r.stack ? String(r.stack).split("\n").slice(0, 3).join("\n") : ""));
  });
})();
